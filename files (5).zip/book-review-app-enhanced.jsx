import React, { useState, useEffect } from 'react';
import { Book, Star, Sparkles, Info, Search, User, MessageSquare, BookOpen, List, Heart, Plus, X, Globe, LogOut, LogIn, UserPlus, ShoppingCart, Building2, Users, UserCheck, UserX } from 'lucide-react';

// Translation object
const translations = {
  da: {
    appTitle: "Boghylde",
    appSubtitle: "Opdag anmeldelser og fascinerende fakta om enhver bog",
    searchPlaceholder: "Indtast en bogtitel...",
    officialRating: "Officiel Bedømmelse",
    readerRating: "Læser Bedømmelse",
    criticsConsensus: "Professionelle kritikeres konsensus",
    basedOnReviews: "Baseret på",
    readerReviews: "læser anmeldelser",
    noReviewsYet: "Ingen læser anmeldelser endnu",
    officialReviews: "Officielle Anmeldelser",
    readerReviewsTitle: "Læser Anmeldelser",
    addYourReview: "Tilføj Din Anmeldelse",
    shareThoughts: "Del Dine Tanker",
    yourName: "Dit Navn",
    enterName: "Indtast dit navn",
    yourRating: "Din Bedømmelse",
    yourReview: "Din Anmeldelse",
    reviewPlaceholder: "Hvad syntes du om denne bog?",
    submitReview: "Indsend Anmeldelse",
    cancel: "Annuller",
    loadingReviews: "Indlæser anmeldelser...",
    noReaderReviews: "Ingen læser anmeldelser endnu. Vær den første til at dele dine tanker!",
    interestingFacts: "Interessante Fakta",
    enterTitle: "Indtast en bogtitel ovenfor for at komme i gang",
    bookNotFound: "Bog ikke fundet. Tjek venligst titlen og prøv igen.",
    fetchError: "Kunne ikke hente boginformation. Prøv venligst igen.",
    login: "Log Ind",
    signup: "Tilmeld",
    logout: "Log Ud",
    myProfile: "Min Profil",
    myReadingLists: "Mine Læselister",
    wantToRead: "Vil Læse",
    currentlyReading: "Læser Nu",
    finished: "Færdig",
    addToList: "Tilføj til Liste",
    removeFromList: "Fjern fra Liste",
    loginPrompt: "Log ind for at gemme bøger til dine lister",
    createAccount: "Opret Konto",
    username: "Brugernavn",
    password: "Adgangskode",
    confirmPassword: "Bekræft Adgangskode",
    alreadyHaveAccount: "Har du allerede en konto?",
    dontHaveAccount: "Har du ikke en konto?",
    publisher: "Forlag",
    publishedDate: "Udgivet",
    pages: "Sider",
    language: "Sprog",
    isbn: "ISBN",
    categories: "Kategorier",
    buyOnSaxo: "Køb på Saxo.com",
    checkingPrice: "Tjekker pris...",
    priceNotAvailable: "Pris ikke tilgængelig",
    findInLibrary: "Find i Bibliotek",
    availableInLibraries: "Tilgængelig på danske biblioteker",
    checkBiblioteketDK: "Tjek på Bibliotek.dk",
    socialFeatures: "Sociale Funktioner",
    following: "Følger",
    followers: "Følgere",
    follow: "Følg",
    unfollow: "Følg ikke længere",
    browseUsers: "Browse Brugere",
    findFriends: "Find Venner",
    activity: "Aktivitet",
    recentActivity: "Seneste Aktivitet",
    addedToList: "tilføjede til",
    reviewedBook: "anmeldte"
  },
  en: {
    appTitle: "Bookshelf",
    appSubtitle: "Discover reviews and fascinating facts about any book",
    searchPlaceholder: "Enter a book title...",
    officialRating: "Official Rating",
    readerRating: "Reader Rating",
    criticsConsensus: "Professional critics consensus",
    basedOnReviews: "Based on",
    readerReviews: "reader reviews",
    noReviewsYet: "No reader reviews yet",
    officialReviews: "Official Reviews",
    readerReviewsTitle: "Reader Reviews",
    addYourReview: "Add Your Review",
    shareThoughts: "Share Your Thoughts",
    yourName: "Your Name",
    enterName: "Enter your name",
    yourRating: "Your Rating",
    yourReview: "Your Review",
    reviewPlaceholder: "What did you think about this book?",
    submitReview: "Submit Review",
    cancel: "Cancel",
    loadingReviews: "Loading reviews...",
    noReaderReviews: "No reader reviews yet. Be the first to share your thoughts!",
    interestingFacts: "Interesting Facts",
    enterTitle: "Enter a book title above to get started",
    bookNotFound: "Book not found. Please check the title and try again.",
    fetchError: "Failed to fetch book information. Please try again.",
    login: "Log In",
    signup: "Sign Up",
    logout: "Log Out",
    myProfile: "My Profile",
    myReadingLists: "My Reading Lists",
    wantToRead: "Want to Read",
    currentlyReading: "Currently Reading",
    finished: "Finished",
    addToList: "Add to List",
    removeFromList: "Remove from List",
    loginPrompt: "Log in to save books to your lists",
    createAccount: "Create Account",
    username: "Username",
    password: "Password",
    confirmPassword: "Confirm Password",
    alreadyHaveAccount: "Already have an account?",
    dontHaveAccount: "Don't have an account?",
    publisher: "Publisher",
    publishedDate: "Published",
    pages: "Pages",
    language: "Language",
    isbn: "ISBN",
    categories: "Categories",
    buyOnSaxo: "Buy on Saxo.com",
    checkingPrice: "Checking price...",
    priceNotAvailable: "Price not available",
    findInLibrary: "Find in Library",
    availableInLibraries: "Available in Danish libraries",
    checkBiblioteketDK: "Check on Bibliotek.dk",
    socialFeatures: "Social Features",
    following: "Following",
    followers: "Followers",
    follow: "Follow",
    unfollow: "Unfollow",
    browseUsers: "Browse Users",
    findFriends: "Find Friends",
    activity: "Activity",
    recentActivity: "Recent Activity",
    addedToList: "added to",
    reviewedBook: "reviewed"
  }
};

export default function BookReviewApp() {
  const [language, setLanguage] = useState('da'); // Default to Danish
  const [bookTitle, setBookTitle] = useState('');
  const [loading, setLoading] = useState(false);
  const [bookData, setBookData] = useState(null);
  const [error, setError] = useState('');
  const [userReviews, setUserReviews] = useState([]);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [newReview, setNewReview] = useState({ name: '', rating: 5, text: '' });
  const [loadingReviews, setLoadingReviews] = useState(false);
  
  // User account state
  const [currentUser, setCurrentUser] = useState(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState('login'); // 'login' or 'signup'
  const [authForm, setAuthForm] = useState({ username: '', password: '', confirmPassword: '' });
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [readingLists, setReadingLists] = useState({
    wantToRead: [],
    currentlyReading: [],
    finished: []
  });

  // Social features state
  const [following, setFollowing] = useState([]);
  const [followers, setFollowers] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [showSocialModal, setShowSocialModal] = useState(false);
  const [socialTab, setSocialTab] = useState('browse'); // 'browse' or 'activity'
  const [recentActivity, setRecentActivity] = useState([]);

  const t = translations[language];

  // Load current user on mount
  useEffect(() => {
    loadCurrentUser();
  }, []);

  // Load reading lists when user changes
  useEffect(() => {
    if (currentUser) {
      loadReadingLists();
      loadFollowing();
      loadFollowers();
    }
  }, [currentUser]);

  // Load all users for browsing
  useEffect(() => {
    loadAllUsers();
  }, []);

  const loadFollowing = async () => {
    if (!currentUser) return;
    console.log('Loading following list for:', currentUser.username);
    try {
      const result = await window.storage.get(`following:${currentUser.username}`, true);
      if (result && result.value) {
        const followingList = JSON.parse(result.value);
        console.log('Following loaded:', followingList);
        setFollowing(followingList);
      } else {
        console.log('No following list found, initializing empty');
        setFollowing([]);
      }
    } catch (err) {
      console.log('Error loading following, initializing empty:', err);
      setFollowing([]);
    }
  };

  const loadFollowers = async () => {
    if (!currentUser) return;
    console.log('Loading followers list for:', currentUser.username);
    try {
      const result = await window.storage.get(`followers:${currentUser.username}`, true);
      if (result && result.value) {
        const followersList = JSON.parse(result.value);
        console.log('Followers loaded:', followersList);
        setFollowers(followersList);
      } else {
        console.log('No followers list found, initializing empty');
        setFollowers([]);
      }
    } catch (err) {
      console.log('Error loading followers, initializing empty:', err);
      setFollowers([]);
    }
  };

  const loadAllUsers = async () => {
    console.log('=== LOADING ALL USERS (AGGRESSIVE) ===');
    let foundUsers = [];
    
    try {
      // Method 1: Check global list
      try {
        const usersListResult = await window.storage.get('all-users-list', true);
        if (usersListResult && usersListResult.value) {
          foundUsers = JSON.parse(usersListResult.value);
          console.log('Found from global list:', foundUsers);
        }
      } catch (err) {
        console.log('No global list');
      }

      // Method 2: Try storage.list
      try {
        const result = await window.storage.list('user:', true);
        if (result && result.keys && result.keys.length > 0) {
          const listUsers = result.keys.map(key => key.replace('user:', ''));
          console.log('Found from storage.list:', listUsers);
          // Merge with existing
          listUsers.forEach(u => {
            if (!foundUsers.includes(u)) foundUsers.push(u);
          });
        }
      } catch (err) {
        console.log('storage.list failed');
      }

      // Method 3: Brute force check common names
      const commonNames = ['sigrid', 'alice', 'bob', 'alice2', 'bob2', 'test', 'testuser', 
                          'anna', 'peter', 'marie', 'lars', 'sofie', 'emma', 'oliver'];
      
      console.log('Checking common usernames...');
      for (const username of commonNames) {
        try {
          const user = await window.storage.get(`user:${username}`);
          if (user && user.value) {
            if (!foundUsers.includes(username)) {
              foundUsers.push(username);
              console.log(`✅ Found: ${username}`);
            }
          }
        } catch (err) {
          // User doesn't exist
        }
      }
      
      console.log('Total users found:', foundUsers);
      
      // Save to global list
      if (foundUsers.length > 0) {
        await window.storage.set('all-users-list', JSON.stringify(foundUsers), true);
        console.log('Saved to global list');
      }
      
      setAllUsers(foundUsers);
      
    } catch (err) {
      console.error('Error in loadAllUsers:', err);
      setAllUsers(foundUsers); // Set whatever we found
    }
    
    console.log('=== LOADING COMPLETED - Found:', foundUsers.length, 'users ===');
  };

  const followUser = async (username) => {
    if (!currentUser || username === currentUser.username) {
      console.log('Cannot follow: no user or trying to follow self');
      return;
    }
    
    console.log('=== FOLLOW USER STARTED ===');
    console.log('Current user:', currentUser.username);
    console.log('Following:', username);
    console.log('Current following list:', following);
    
    try {
      const newFollowing = [...following, username];
      console.log('New following list:', newFollowing);
      
      await window.storage.set(`following:${currentUser.username}`, JSON.stringify(newFollowing), true);
      console.log('Following list saved to storage');
      
      setFollowing(newFollowing);
      console.log('State updated with new following list');
      
      // Add to the other user's followers
      try {
        const result = await window.storage.get(`followers:${username}`, true);
        const theirFollowers = result && result.value ? JSON.parse(result.value) : [];
        console.log(`${username}'s current followers:`, theirFollowers);
        
        theirFollowers.push(currentUser.username);
        await window.storage.set(`followers:${username}`, JSON.stringify(theirFollowers), true);
        console.log(`Added to ${username}'s followers`);
      } catch (err) {
        console.log(`Creating new followers list for ${username}`);
        await window.storage.set(`followers:${username}`, JSON.stringify([currentUser.username]), true);
      }
      
      // Log activity
      await logActivity('follow', username);
      console.log('Activity logged');
      
      alert(language === 'da' 
        ? `✅ Du følger nu ${username}!` 
        : `✅ You are now following ${username}!`);
      
      console.log('=== FOLLOW USER COMPLETED ===');
    } catch (err) {
      console.error('=== FOLLOW USER ERROR ===');
      console.error('Error:', err);
      alert(language === 'da' 
        ? `❌ Kunne ikke følge ${username}. Fejl: ${err.message}` 
        : `❌ Could not follow ${username}. Error: ${err.message}`);
    }
  };

  const unfollowUser = async (username) => {
    if (!currentUser) {
      console.log('Cannot unfollow: no current user');
      return;
    }
    
    console.log('=== UNFOLLOW USER STARTED ===');
    console.log('Current user:', currentUser.username);
    console.log('Unfollowing:', username);
    console.log('Current following list:', following);
    
    try {
      const newFollowing = following.filter(u => u !== username);
      console.log('New following list:', newFollowing);
      
      await window.storage.set(`following:${currentUser.username}`, JSON.stringify(newFollowing), true);
      console.log('Following list saved to storage');
      
      setFollowing(newFollowing);
      console.log('State updated');
      
      // Remove from the other user's followers
      try {
        const result = await window.storage.get(`followers:${username}`, true);
        if (result && result.value) {
          const theirFollowers = JSON.parse(result.value).filter(u => u !== currentUser.username);
          await window.storage.set(`followers:${username}`, JSON.stringify(theirFollowers), true);
          console.log(`Removed from ${username}'s followers`);
        }
      } catch (err) {
        console.log('Error updating followers:', err);
      }
      
      alert(language === 'da' 
        ? `✅ Du følger ikke længere ${username}` 
        : `✅ You unfollowed ${username}`);
      
      console.log('=== UNFOLLOW USER COMPLETED ===');
    } catch (err) {
      console.error('=== UNFOLLOW USER ERROR ===');
      console.error('Error:', err);
      alert(language === 'da' 
        ? `❌ Kunne ikke stoppe med at følge ${username}` 
        : `❌ Could not unfollow ${username}`);
    }
  };

  const logActivity = async (action, details) => {
    if (!currentUser) return;
    
    const activity = {
      username: currentUser.username,
      action,
      details,
      timestamp: new Date().toISOString()
    };
    
    try {
      const result = await window.storage.get('global-activity', true);
      const activities = result && result.value ? JSON.parse(result.value) : [];
      activities.unshift(activity);
      // Keep only last 50 activities
      const trimmed = activities.slice(0, 50);
      await window.storage.set('global-activity', JSON.stringify(trimmed), true);
    } catch (err) {
      await window.storage.set('global-activity', JSON.stringify([activity]), true);
    }
  };

  const loadRecentActivity = async () => {
    try {
      const result = await window.storage.get('global-activity', true);
      if (result && result.value) {
        const activities = JSON.parse(result.value);
        // Filter to show only activities from people the current user follows
        if (currentUser) {
          const filtered = activities.filter(a => 
            following.includes(a.username) || a.username === currentUser.username
          );
          setRecentActivity(filtered.slice(0, 20));
        } else {
          setRecentActivity(activities.slice(0, 20));
        }
      }
    } catch (err) {
      setRecentActivity([]);
    }
  };

  const loadCurrentUser = async () => {
    try {
      const result = await window.storage.get('current-user');
      if (result && result.value) {
        const user = JSON.parse(result.value);
        setCurrentUser(user);
      }
    } catch (err) {
      console.log('No current user logged in');
      setCurrentUser(null);
    }
  };

  const loadReadingLists = async () => {
    if (!currentUser) return;
    try {
      const result = await window.storage.get(`reading-lists:${currentUser.username}`);
      if (result && result.value) {
        setReadingLists(JSON.parse(result.value));
      } else {
        // Initialize empty lists if none exist
        const emptyLists = {
          wantToRead: [],
          currentlyReading: [],
          finished: []
        };
        setReadingLists(emptyLists);
      }
    } catch (err) {
      console.log('No reading lists found, initializing empty lists');
      setReadingLists({
        wantToRead: [],
        currentlyReading: [],
        finished: []
      });
    }
  };

  const saveReadingLists = async (lists) => {
    if (!currentUser) return;
    try {
      await window.storage.set(`reading-lists:${currentUser.username}`, JSON.stringify(lists));
      setReadingLists(lists);
    } catch (err) {
      console.error('Error saving reading lists:', err);
    }
  };

  const handleLogin = async () => {
    console.log('=== LOGIN STARTED ===');
    console.log('Username:', authForm.username);
    console.log('Password length:', authForm.password?.length);

    if (!authForm.username || !authForm.password) {
      alert(language === 'da' ? 'Udfyld venligst alle felter' : 'Please fill in all fields');
      console.log('ERROR: Missing fields');
      return;
    }

    try {
      console.log('Trying to get user:', authForm.username);
      const result = await window.storage.get(`user:${authForm.username}`);
      console.log('Storage get result:', result);
      
      if (result && result.value) {
        const user = JSON.parse(result.value);
        console.log('User found:', user.username);
        console.log('Stored password:', user.password);
        console.log('Entered password:', authForm.password);
        console.log('Passwords match:', user.password === authForm.password);
        
        if (user.password === authForm.password) {
          console.log('✅ Password correct!');
          setCurrentUser(user);
          await window.storage.set('current-user', JSON.stringify(user));
          setShowAuthModal(false);
          setAuthForm({ username: '', password: '', confirmPassword: '' });
          
          alert(language === 'da' ? '✅ Logget ind!' : '✅ Logged in!');
          console.log('=== LOGIN SUCCESS ===');
        } else {
          console.log('❌ Wrong password');
          alert(language === 'da' ? '❌ Forkert adgangskode' : '❌ Incorrect password');
        }
      } else {
        console.log('❌ User not found in storage');
        alert(language === 'da' ? '❌ Bruger ikke fundet' : '❌ User not found');
      }
    } catch (err) {
      console.error('=== LOGIN ERROR ===');
      console.error('Error:', err);
      console.error('Error message:', err.message);
      
      alert(language === 'da' 
        ? `❌ Login fejlede: ${err.message}. Prøv at oprette kontoen igen.` 
        : `❌ Login failed: ${err.message}. Try creating the account again.`);
    }
  };

  const handleSignup = async () => {
    console.log('=== SIGNUP STARTED ===');
    console.log('Username:', authForm.username);
    console.log('Password length:', authForm.password?.length);
    console.log('Confirm password length:', authForm.confirmPassword?.length);

    if (!authForm.username || !authForm.password || !authForm.confirmPassword) {
      const msg = language === 'da' ? 'Udfyld venligst alle felter' : 'Please fill in all fields';
      alert(msg);
      console.log('ERROR: Missing fields');
      return;
    }

    if (authForm.password !== authForm.confirmPassword) {
      const msg = language === 'da' ? 'Adgangskoderne matcher ikke' : 'Passwords do not match';
      alert(msg);
      console.log('ERROR: Passwords do not match');
      return;
    }

    if (authForm.username.length < 3) {
      const msg = language === 'da' ? 'Brugernavn skal være mindst 3 tegn' : 'Username must be at least 3 characters';
      alert(msg);
      console.log('ERROR: Username too short');
      return;
    }

    if (authForm.password.length < 4) {
      const msg = language === 'da' ? 'Adgangskode skal være mindst 4 tegn' : 'Password must be at least 4 characters';
      alert(msg);
      console.log('ERROR: Password too short');
      return;
    }

    try {
      console.log('Checking if user exists...');
      // Check if user already exists
      try {
        const existingUser = await window.storage.get(`user:${authForm.username}`);
        if (existingUser && existingUser.value) {
          const msg = language === 'da' ? 'Brugernavn er allerede taget' : 'Username already exists';
          alert(msg);
          console.log('ERROR: User already exists');
          return;
        }
      } catch (err) {
        // User doesn't exist, which is good for signup
        console.log('User does not exist, proceeding with signup (this is good!)');
      }

      console.log('Creating new user...');
      const newUser = { 
        username: authForm.username, 
        password: authForm.password,
        createdAt: new Date().toISOString()
      };
      
      console.log('Saving user to storage...');
      await window.storage.set(`user:${authForm.username}`, JSON.stringify(newUser), true);
      console.log('User saved successfully!');
      
      // IMPORTANT: Add user to global users list
      try {
        const usersListResult = await window.storage.get('all-users-list', true);
        let usersList = [];
        if (usersListResult && usersListResult.value) {
          usersList = JSON.parse(usersListResult.value);
        }
        if (!usersList.includes(authForm.username)) {
          usersList.push(authForm.username);
          await window.storage.set('all-users-list', JSON.stringify(usersList), true);
          console.log('User added to global users list:', usersList);
        }
      } catch (err) {
        console.log('Creating new users list');
        await window.storage.set('all-users-list', JSON.stringify([authForm.username]), true);
      }
      
      setCurrentUser(newUser);
      console.log('Current user set!');
      
      await window.storage.set('current-user', JSON.stringify(newUser));
      console.log('Current user saved to storage!');
      
      // Initialize empty reading lists for new user
      const emptyLists = {
        wantToRead: [],
        currentlyReading: [],
        finished: []
      };
      
      console.log('Initializing reading lists...');
      await window.storage.set(`reading-lists:${newUser.username}`, JSON.stringify(emptyLists));
      console.log('Reading lists initialized!');
      
      // Initialize empty following/followers
      await window.storage.set(`following:${newUser.username}`, JSON.stringify([]), true);
      await window.storage.set(`followers:${newUser.username}`, JSON.stringify([]), true);
      console.log('Social features initialized!');
      
      setShowAuthModal(false);
      setAuthForm({ username: '', password: '', confirmPassword: '' });
      
      const successMsg = language === 'da' ? '🎉 Konto oprettet! Velkommen!' : '🎉 Account created! Welcome!';
      alert(successMsg);
      console.log('=== SIGNUP COMPLETED SUCCESSFULLY ===');
      
      // Reload to update UI
      await loadAllUsers();
      
    } catch (err) {
      console.error('=== SIGNUP ERROR ===');
      console.error('Error details:', err);
      console.error('Error message:', err.message);
      console.error('Error stack:', err.stack);
      
      const errorMsg = language === 'da' 
        ? `Kunne ikke oprette konto. Fejl: ${err.message}` 
        : `Could not create account. Error: ${err.message}`;
      alert(errorMsg);
    }
  };

  const handleLogout = async () => {
    setCurrentUser(null);
    await window.storage.delete('current-user');
    setShowProfileModal(false);
  };

  const addToReadingList = async (listName, book) => {
    if (!currentUser) {
      alert(t.loginPrompt);
      setShowAuthModal(true);
      return;
    }

    const bookItem = {
      id: book.id,
      title: book.volumeInfo.title,
      authors: book.volumeInfo.authors,
      thumbnail: book.volumeInfo.imageLinks?.thumbnail,
      addedDate: new Date().toISOString()
    };

    const newLists = { ...readingLists };
    
    // Remove from other lists if exists
    Object.keys(newLists).forEach(key => {
      newLists[key] = newLists[key].filter(b => b.id !== book.id);
    });
    
    // Add to selected list
    newLists[listName] = [...newLists[listName], bookItem];
    await saveReadingLists(newLists);
    
    // Log activity
    await logActivity('addedToList', { 
      listName, 
      bookTitle: book.volumeInfo.title 
    });
  };

  const removeFromReadingList = async (listName, bookId) => {
    const newLists = { ...readingLists };
    newLists[listName] = newLists[listName].filter(b => b.id !== bookId);
    await saveReadingLists(newLists);
  };

  const isInReadingList = (bookId) => {
    for (let list in readingLists) {
      if (readingLists[list].some(b => b.id === bookId)) {
        return list;
      }
    }
    return null;
  };

  const fetchBookInfo = async (title) => {
    setLoading(true);
    setError('');
    setBookData(null);

    console.log('Starting search for:', title);

    // Always use AI-based search since it's more reliable
    try {
      await fetchAIOnlyContent(title);
    } catch (err) {
      console.error('Fatal error in fetchBookInfo:', err);
      setError(language === 'da' 
        ? 'Der opstod en fejl. Prøv venligst igen.' 
        : 'An error occurred. Please try again.');
      setLoading(false);
    }
  };

  const fetchAIOnlyContent = async (title) => {
    console.log('fetchAIOnlyContent called with:', title);
    
    try {
      console.log('Making API call to Claude...');
      
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1500,
          messages: [
            {
              role: "user",
              content: `Giv mig information om bogen "${title}". Svar UDELUKKENDE med JSON i dette format (ingen markdown, ingen backticks):

{
  "title": "Bogens fulde titel",
  "authors": ["Forfatterens navn"],
  "publisher": "Forlag",
  "publishedDate": "2020",
  "description": "En kort beskrivelse af bogen på 2-3 sætninger",
  "pageCount": 300,
  "categories": ["Genre"],
  "industryIdentifiers": [
    {"type": "ISBN_13", "identifier": "9781234567890"}
  ],
  "rating": 4.5,
  "reviews": [
    {
      "reviewer": "Anmelder eller publikation",
      "rating": 4,
      "text": "En kort anmeldelse"
    },
    {
      "reviewer": "En anden kilde",
      "rating": 5,
      "text": "Endnu en anmeldelse"
    }
  ],
  "facts": [
    "En interessant fakta om bogen",
    "Endnu en interessant detalje",
    "En tredje fascinerende ting"
  ]
}

VIGTIGT: Inkluder ISBN nummer hvis du kender det - dette er vigtigt for links til boghandler.`
            }
          ],
        })
      });

      console.log('API response status:', response.status);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('API error response:', errorText);
        throw new Error(`API responded with status ${response.status}`);
      }

      const aiData = await response.json();
      console.log('API response received:', aiData);
      
      if (!aiData.content || aiData.content.length === 0) {
        console.error('Empty content in API response');
        throw new Error('Empty response from API');
      }

      const text = aiData.content
        .map(item => (item.type === "text" ? item.text : ""))
        .filter(Boolean)
        .join("\n");

      console.log('Extracted text:', text.substring(0, 200) + '...');

      const cleanText = text.replace(/```json|```/g, "").trim();
      
      let aiContent;
      try {
        aiContent = JSON.parse(cleanText);
        console.log('Successfully parsed JSON:', aiContent);
      } catch (parseError) {
        console.error('JSON parse error:', parseError);
        console.error('Attempted to parse:', cleanText);
        throw new Error('Failed to parse book data');
      }

      // Create book data structure
      const mockBook = {
        id: `book-${Date.now()}`,
        volumeInfo: {
          title: aiContent.title || title,
          authors: aiContent.authors || ['Ukendt Forfatter'],
          publisher: aiContent.publisher || 'Ukendt',
          publishedDate: aiContent.publishedDate || 'Ukendt',
          description: aiContent.description || 'Ingen beskrivelse tilgængelig',
          pageCount: aiContent.pageCount || 0,
          categories: aiContent.categories || ['Ukendt'],
          industryIdentifiers: aiContent.industryIdentifiers || [],
          imageLinks: {
            thumbnail: ''
          }
        }
      };

      console.log('Setting book data:', mockBook);

      setBookData({
        ...mockBook,
        aiRating: aiContent.rating || 0,
        aiReviews: aiContent.reviews || [],
        facts: aiContent.facts || []
      });

      await loadUserReviews(aiContent.title || title);
      setLoading(false);
      console.log('Book data loaded successfully!');
      
    } catch (err) {
      console.error('Error in fetchAIOnlyContent:', err);
      console.error('Error stack:', err.stack);
      
      setError(language === 'da' 
        ? `Kunne ikke finde bogen "${title}". Fejl: ${err.message}`
        : `Could not find the book "${title}". Error: ${err.message}`
      );
      setLoading(false);
    }
  };

  const fetchAIContent = async (book) => {
    const bookTitle = book.volumeInfo.title;
    const author = book.volumeInfo.authors?.[0] || 'Unknown';

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [
            {
              role: "user",
              content: `Please provide reviews and facts about the book "${bookTitle}" by ${author} in ${language === 'da' ? 'DANISH' : 'ENGLISH'} language. Return ONLY valid JSON with no markdown formatting:

{
  "rating": 4.5,
  "reviews": [
    {
      "reviewer": "reviewer name",
      "rating": 5,
      "text": "review text"
    }
  ],
  "facts": [
    "interesting fact 1",
    "interesting fact 2",
    "interesting fact 3"
  ]
}

If unknown, use generic literary reviews.`
            }
          ],
        })
      });

      const aiData = await response.json();
      const text = aiData.content
        .map(item => (item.type === "text" ? item.text : ""))
        .filter(Boolean)
        .join("\n");

      const cleanText = text.replace(/```json|```/g, "").trim();
      const aiContent = JSON.parse(cleanText);

      // Combine Google Books data with AI content
      setBookData({
        ...book,
        aiRating: aiContent.rating,
        aiReviews: aiContent.reviews,
        facts: aiContent.facts
      });

      await loadUserReviews(bookTitle);
    } catch (err) {
      console.error('Error fetching AI content:', err);
      // Set book data without AI content
      setBookData({
        ...book,
        aiRating: 0,
        aiReviews: [],
        facts: []
      });
      await loadUserReviews(bookTitle);
    }
  };

  const loadUserReviews = async (bookTitle) => {
    setLoadingReviews(true);
    try {
      const normalizedTitle = bookTitle.toLowerCase().replace(/[^a-z0-9]/g, '-');
      const result = await window.storage.get(`reviews:${normalizedTitle}`, true);
      if (result && result.value) {
        setUserReviews(JSON.parse(result.value));
      } else {
        setUserReviews([]);
      }
    } catch (err) {
      console.log('No existing reviews found');
      setUserReviews([]);
    } finally {
      setLoadingReviews(false);
    }
  };

  const saveUserReview = async () => {
    if (!newReview.name.trim() || !newReview.text.trim()) {
      alert('Please fill in all fields');
      return;
    }

    try {
      const normalizedTitle = bookData.volumeInfo.title.toLowerCase().replace(/[^a-z0-9]/g, '-');
      const updatedReviews = [...userReviews, {
        ...newReview,
        date: new Date().toISOString(),
        username: currentUser?.username
      }];
      
      await window.storage.set(`reviews:${normalizedTitle}`, JSON.stringify(updatedReviews), true);
      setUserReviews(updatedReviews);
      setNewReview({ name: '', rating: 5, text: '' });
      setShowReviewForm(false);
      
      // Log activity
      if (currentUser) {
        await logActivity('reviewedBook', { 
          bookTitle: bookData.volumeInfo.title,
          rating: newReview.rating 
        });
      }
    } catch (err) {
      console.error('Error saving review:', err);
      alert('Failed to save review. Please try again.');
    }
  };

  const calculateUserRating = () => {
    if (userReviews.length === 0) return 0;
    const sum = userReviews.reduce((acc, review) => acc + review.rating, 0);
    return (sum / userReviews.length).toFixed(1);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (bookTitle.trim()) {
      fetchBookInfo(bookTitle.trim());
    }
  };

  const renderStars = (rating, whiteStars = false) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    return (
      <div className="flex gap-1">
        {[...Array(5)].map((_, i) => {
          if (i < fullStars) {
            return (
              <Star
                key={i}
                size={20}
                className={whiteStars ? "fill-white text-white" : "fill-amber-400 text-amber-400"}
              />
            );
          } else if (i === fullStars && hasHalfStar) {
            return (
              <div key={i} className="relative">
                <Star
                  size={20}
                  className={whiteStars ? "text-white/30" : "text-gray-300"}
                />
                <div className="absolute inset-0 overflow-hidden" style={{width: '50%'}}>
                  <Star
                    size={20}
                    className={whiteStars ? "fill-white text-white" : "fill-amber-400 text-amber-400"}
                  />
                </div>
              </div>
            );
          } else {
            return (
              <Star
                key={i}
                size={20}
                className={whiteStars ? "text-white/30" : "text-gray-300"}
              />
            );
          }
        })}
      </div>
    );
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Decorative background circles */}
      <div className="decorative-circle float-animation" style={{width: '400px', height: '400px', top: '-200px', right: '-100px'}}></div>
      <div className="decorative-circle float-animation" style={{width: '300px', height: '300px', bottom: '-150px', left: '-50px', animationDelay: '2s'}}></div>
      
      <div className="max-w-6xl mx-auto p-6 relative z-10">
        {/* Header with Language Switcher and User Menu */}
        <div className="flex justify-between items-center mb-8 pt-4">
          <button
            onClick={() => setLanguage(language === 'da' ? 'en' : 'da')}
            className="flex items-center gap-2 bg-white/80 backdrop-blur px-4 py-2 rounded-xl border border-gray-200 hover:border-rose-300 transition-all"
          >
            <Globe size={20} className="text-rose-600" />
            <span className="font-medium">{language === 'da' ? '🇩🇰 Dansk' : '🇬🇧 English'}</span>
          </button>

          <div className="flex items-center gap-3">
            {currentUser ? (
              <>
                <button
                  onClick={async () => {
                    setShowSocialModal(true);
                    // Force reload users when opening
                    console.log('Social modal opened - reloading users');
                    await loadAllUsers();
                    await loadRecentActivity();
                  }}
                  className="flex items-center gap-2 bg-white/80 backdrop-blur px-4 py-2 rounded-xl border border-gray-200 hover:border-purple-300 transition-all"
                >
                  <Users size={18} className="text-purple-600" />
                  <span className="font-medium hidden sm:inline">{t.socialFeatures}</span>
                </button>
                <button
                  onClick={() => setShowProfileModal(true)}
                  className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-xl hover:shadow-lg transition-all"
                >
                  <User size={18} />
                  <span className="font-medium">{currentUser.username}</span>
                  {followers.length > 0 && (
                    <span className="bg-white/20 px-2 py-0.5 rounded-full text-xs">
                      {followers.length}
                    </span>
                  )}
                </button>
              </>
            ) : (
              <button
                onClick={() => {
                  setAuthMode('login');
                  setShowAuthModal(true);
                }}
                className="flex items-center gap-2 bg-white/80 backdrop-blur px-4 py-2 rounded-xl border border-gray-200 hover:border-blue-300 transition-all"
              >
                <LogIn size={18} className="text-blue-600" />
                <span className="font-medium">{t.login}</span>
              </button>
            )}
          </div>
        </div>

        {/* App Title */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-3 mb-4">
            <Book size={48} className="text-rose-600" strokeWidth={1.5} />
            <h1 className="text-6xl font-serif italic text-gray-900">{t.appTitle}</h1>
          </div>
          <p className="text-gray-600 text-lg font-light">{t.appSubtitle}</p>
        </div>

        {/* Search Form */}
        <form onSubmit={handleSubmit} className="mb-12">
          <div className="relative">
            <input
              type="text"
              value={bookTitle}
              onChange={(e) => setBookTitle(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full px-6 py-4 pr-14 text-lg rounded-2xl border-2 border-rose-200 focus:border-rose-400 focus:outline-none bg-white/80 backdrop-blur shadow-lg placeholder:text-gray-400"
            />
            <button
              type="submit"
              disabled={loading || !bookTitle.trim()}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-gradient-to-r from-rose-500 to-purple-600 text-white p-3 rounded-xl hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 hover:scale-105"
            >
              {loading ? (
                <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div>
              ) : (
                <Search size={20} />
              )}
            </button>
          </div>
        </form>

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border-2 border-red-200 text-red-700 px-6 py-4 rounded-2xl mb-8">
            {error}
          </div>
        )}

        {/* Book Information */}
        {bookData && (
          <div className="space-y-8 animate-fadeIn">
            {/* Book Header with Cover */}
            <div className="bg-white/90 backdrop-blur rounded-3xl p-8 shadow-xl border-2 border-rose-100">
              <div className="flex items-start gap-6">
                {bookData.volumeInfo.imageLinks?.thumbnail && (
                  <img
                    src={bookData.volumeInfo.imageLinks.thumbnail}
                    alt={bookData.volumeInfo.title}
                    className="w-32 h-48 object-cover rounded-xl shadow-lg"
                  />
                )}
                <div className="flex-1">
                  <h2 className="text-4xl font-serif mb-2 text-gray-900">{bookData.volumeInfo.title}</h2>
                  <p className="text-xl text-gray-600 mb-3">
                    {bookData.volumeInfo.authors?.join(', ') || 'Unknown Author'}
                  </p>
                  
                  {/* Book metadata */}
                  <div className="flex flex-wrap gap-3 text-sm text-gray-600 mb-4">
                    {bookData.volumeInfo.publisher && (
                      <span className="bg-gray-100 px-3 py-1 rounded-full">
                        {t.publisher}: {bookData.volumeInfo.publisher}
                      </span>
                    )}
                    {bookData.volumeInfo.publishedDate && (
                      <span className="bg-gray-100 px-3 py-1 rounded-full">
                        {t.publishedDate}: {bookData.volumeInfo.publishedDate.split('-')[0]}
                      </span>
                    )}
                    {bookData.volumeInfo.pageCount && (
                      <span className="bg-gray-100 px-3 py-1 rounded-full">
                        {bookData.volumeInfo.pageCount} {t.pages}
                      </span>
                    )}
                  </div>

                  {/* Reading List Buttons */}
                  {currentUser && (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {isInReadingList(bookData.id) ? (
                        <button
                          onClick={() => removeFromReadingList(isInReadingList(bookData.id), bookData.id)}
                          className="flex items-center gap-2 bg-red-100 text-red-700 px-4 py-2 rounded-xl hover:bg-red-200 transition-all text-sm"
                        >
                          <X size={16} />
                          {t.removeFromList}
                        </button>
                      ) : (
                        <>
                          <button
                            onClick={() => addToReadingList('wantToRead', bookData)}
                            className="flex items-center gap-2 bg-blue-100 text-blue-700 px-3 py-2 rounded-xl hover:bg-blue-200 transition-all text-sm"
                          >
                            <Plus size={16} />
                            {t.wantToRead}
                          </button>
                          <button
                            onClick={() => addToReadingList('currentlyReading', bookData)}
                            className="flex items-center gap-2 bg-orange-100 text-orange-700 px-3 py-2 rounded-xl hover:bg-orange-200 transition-all text-sm"
                          >
                            <BookOpen size={16} />
                            {t.currentlyReading}
                          </button>
                          <button
                            onClick={() => addToReadingList('finished', bookData)}
                            className="flex items-center gap-2 bg-green-100 text-green-700 px-3 py-2 rounded-xl hover:bg-green-200 transition-all text-sm"
                          >
                            <Star size={16} />
                            {t.finished}
                          </button>
                        </>
                      )}
                    </div>
                  )}
                  
                  {/* Ratings Display */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                    {/* Official Rating Card */}
                    <div className="relative overflow-hidden bg-gradient-to-br from-amber-500 to-orange-600 p-6 rounded-2xl shadow-lg transform transition-transform hover:scale-105">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                      <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
                      <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-3">
                          <Star className="text-white fill-white" size={20} />
                          <p className="text-sm font-bold text-white/90 tracking-wide uppercase">{t.officialRating}</p>
                        </div>
                        <div className="flex items-end gap-3 mb-3">
                          <span className="text-6xl font-bold text-white leading-none">{bookData.aiRating || '--'}</span>
                          <span className="text-2xl text-white/80 pb-2">/5</span>
                        </div>
                        <div className="flex gap-1">
                          {renderStars(bookData.aiRating || 0, true)}
                        </div>
                        <p className="text-white/70 text-sm mt-3">{t.criticsConsensus}</p>
                      </div>
                    </div>

                    {/* Reader Rating Card */}
                    <div className="relative overflow-hidden bg-gradient-to-br from-blue-500 to-purple-600 p-6 rounded-2xl shadow-lg transform transition-transform hover:scale-105">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                      <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
                      <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-3">
                          <User className="text-white" size={20} />
                          <p className="text-sm font-bold text-white/90 tracking-wide uppercase">{t.readerRating}</p>
                        </div>
                        {userReviews.length > 0 ? (
                          <>
                            <div className="flex items-end gap-3 mb-3">
                              <span className="text-6xl font-bold text-white leading-none">{calculateUserRating()}</span>
                              <span className="text-2xl text-white/80 pb-2">/5</span>
                            </div>
                            <div className="flex gap-1">
                              {renderStars(parseFloat(calculateUserRating()), true)}
                            </div>
                            <p className="text-white/70 text-sm mt-3">
                              {t.basedOnReviews} {userReviews.length} {t.readerReviews}
                            </p>
                          </>
                        ) : (
                          <>
                            <div className="flex items-end gap-3 mb-3">
                              <span className="text-6xl font-bold text-white/50 leading-none">--</span>
                              <span className="text-2xl text-white/50 pb-2">/5</span>
                            </div>
                            <div className="flex gap-1">
                              {renderStars(0, true)}
                            </div>
                            <p className="text-white/70 text-sm mt-3">{t.noReviewsYet}</p>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Book description */}
              {bookData.volumeInfo.description && (
                <p className="mt-6 text-gray-700 leading-relaxed text-lg">
                  {bookData.volumeInfo.description.replace(/<[^>]*>/g, '').substring(0, 400)}...
                </p>
              )}

              {/* Purchase and Library Links */}
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Saxo.com Link */}
                <a
                  href={(() => {
                    // Use simple search - most reliable
                    const title = bookData.volumeInfo.title;
                    const author = bookData.volumeInfo.authors?.[0] || '';
                    
                    // Clean up title - remove subtitles after colon for better results
                    const cleanTitle = title.split(':')[0].trim();
                    
                    // Build search query: "title author"
                    const searchQuery = `${cleanTitle} ${author}`.trim();
                    
                    return `https://www.saxo.com/dk/search?q=${encodeURIComponent(searchQuery)}`;
                  })()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white px-6 py-4 rounded-xl hover:shadow-lg transition-all transform hover:scale-105"
                >
                  <ShoppingCart size={20} />
                  <div className="text-left">
                    <div className="font-semibold">{t.buyOnSaxo}</div>
                    <div className="text-xs text-white/80">
                      Søger: "{bookData.volumeInfo.title.split(':')[0]}"
                    </div>
                  </div>
                </a>

                {/* Library Link */}
                <a
                  href={(() => {
                    const title = bookData.volumeInfo.title.split(':')[0].trim();
                    const author = bookData.volumeInfo.authors?.[0] || '';
                    
                    return `https://bibliotek.dk/search/work?search=${encodeURIComponent(title + ' ' + author)}`;
                  })()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-3 bg-gradient-to-r from-indigo-500 to-blue-600 text-white px-6 py-4 rounded-xl hover:shadow-lg transition-all transform hover:scale-105"
                >
                  <Building2 size={20} />
                  <div className="text-left">
                    <div className="font-semibold">{t.findInLibrary}</div>
                    <div className="text-xs text-white/80">{t.checkBiblioteketDK}</div>
                  </div>
                </a>
              </div>
            </div>

            {/* Official Reviews Section */}
            {bookData.aiReviews && bookData.aiReviews.length > 0 && (
              <div className="bg-white/90 backdrop-blur rounded-3xl p-8 shadow-xl border-2 border-purple-100">
                <div className="flex items-center gap-3 mb-6">
                  <Star className="text-amber-500" size={28} />
                  <h3 className="text-3xl font-serif text-gray-900">{t.officialReviews}</h3>
                </div>
                <div className="space-y-4">
                  {bookData.aiReviews.map((review, index) => (
                    <div
                      key={index}
                      className="bg-gradient-to-r from-purple-50 to-rose-50 p-6 rounded-2xl border border-purple-100"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-semibold text-gray-800">{review.reviewer}</span>
                        <div className="flex gap-1">
                          {renderStars(review.rating)}
                        </div>
                      </div>
                      <p className="text-gray-700 leading-relaxed">{review.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* User Reviews Section */}
            <div className="bg-white/90 backdrop-blur rounded-3xl p-8 shadow-xl border-2 border-blue-100">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <MessageSquare className="text-blue-500" size={28} />
                  <h3 className="text-3xl font-serif text-gray-900">{t.readerReviewsTitle}</h3>
                </div>
                <button
                  onClick={() => setShowReviewForm(!showReviewForm)}
                  className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-xl hover:shadow-lg transition-all duration-300 hover:scale-105 flex items-center gap-2"
                >
                  <User size={18} />
                  {t.addYourReview}
                </button>
              </div>

              {/* Review Form */}
              {showReviewForm && (
                <div className="mb-6 bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-2xl border-2 border-blue-200">
                  <h4 className="font-semibold text-gray-800 mb-4">{t.shareThoughts}</h4>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">{t.yourName}</label>
                      <input
                        type="text"
                        value={newReview.name}
                        onChange={(e) => setNewReview({...newReview, name: e.target.value})}
                        placeholder={t.enterName}
                        className="w-full px-4 py-2 rounded-xl border border-blue-200 focus:border-blue-400 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">{t.yourRating}</label>
                      <div className="flex gap-2">
                        {[1, 2, 3, 4, 5].map((rating) => (
                          <button
                            key={rating}
                            type="button"
                            onClick={() => setNewReview({...newReview, rating})}
                            className="focus:outline-none transition-transform hover:scale-110"
                          >
                            <Star
                              size={32}
                              className={rating <= newReview.rating ? "fill-amber-400 text-amber-400" : "text-gray-300"}
                            />
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">{t.yourReview}</label>
                      <textarea
                        value={newReview.text}
                        onChange={(e) => setNewReview({...newReview, text: e.target.value})}
                        placeholder={t.reviewPlaceholder}
                        rows="4"
                        className="w-full px-4 py-2 rounded-xl border border-blue-200 focus:border-blue-400 focus:outline-none resize-none"
                      />
                    </div>
                    <div className="flex gap-3">
                      <button
                        onClick={saveUserReview}
                        className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-xl hover:shadow-lg transition-all"
                      >
                        {t.submitReview}
                      </button>
                      <button
                        onClick={() => {
                          setShowReviewForm(false);
                          setNewReview({ name: '', rating: 5, text: '' });
                        }}
                        className="bg-gray-200 text-gray-700 px-6 py-2 rounded-xl hover:bg-gray-300 transition-all"
                      >
                        {t.cancel}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* User Reviews List */}
              {loadingReviews ? (
                <div className="text-center py-8 text-gray-500">{t.loadingReviews}</div>
              ) : userReviews.length > 0 ? (
                <div className="space-y-4">
                  {userReviews.map((review, index) => (
                    <div
                      key={index}
                      className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-2xl border border-blue-100"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <div className="bg-blue-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-semibold">
                            {review.name.charAt(0).toUpperCase()}
                          </div>
                          <span className="font-semibold text-gray-800">{review.name}</span>
                        </div>
                        <div className="flex gap-1">
                          {renderStars(review.rating)}
                        </div>
                      </div>
                      <p className="text-gray-700 leading-relaxed">{review.text}</p>
                      <p className="text-xs text-gray-500 mt-2">
                        {new Date(review.date).toLocaleDateString(language === 'da' ? 'da-DK' : 'en-US')}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <User size={48} className="text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">{t.noReaderReviews}</p>
                </div>
              )}
            </div>

            {/* Facts Section */}
            {bookData.facts && bookData.facts.length > 0 && (
              <div className="bg-white/90 backdrop-blur rounded-3xl p-8 shadow-xl border-2 border-orange-100">
                <div className="flex items-center gap-3 mb-6">
                  <Sparkles className="text-orange-500" size={28} />
                  <h3 className="text-3xl font-serif text-gray-900">{t.interestingFacts}</h3>
                </div>
                <div className="space-y-3">
                  {bookData.facts.map((fact, index) => (
                    <div
                      key={index}
                      className="flex items-start gap-4 bg-gradient-to-r from-orange-50 to-rose-50 p-5 rounded-2xl border border-orange-100"
                    >
                      <Info className="text-orange-500 mt-1 flex-shrink-0" size={20} />
                      <p className="text-gray-700 leading-relaxed">{fact}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Initial State */}
        {!bookData && !loading && !error && (
          <div className="text-center py-16">
            <div className="inline-block p-8 bg-white/60 backdrop-blur rounded-3xl border-2 border-dashed border-rose-200">
              <Book size={64} className="text-rose-300 mx-auto mb-4" strokeWidth={1.5} />
              <p className="text-gray-500 text-lg">{t.enterTitle}</p>
            </div>
          </div>
        )}
      </div>

      {/* Auth Modal */}
      {showAuthModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-3xl font-serif">
                {authMode === 'login' ? t.login : t.createAccount}
              </h3>
              <button
                onClick={() => {
                  setShowAuthModal(false);
                  setAuthForm({ username: '', password: '', confirmPassword: '' });
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X size={24} />
              </button>
            </div>

            {/* Instructions */}
            {authMode === 'signup' && (
              <div className="mb-6 bg-blue-50 border border-blue-200 rounded-xl p-4">
                <p className="text-sm text-blue-800">
                  {language === 'da' 
                    ? '📝 Opret din konto for at følge andre læsere og gemme dine yndlingsbøger!'
                    : '📝 Create your account to follow other readers and save your favorite books!'}
                </p>
              </div>
            )}
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {t.username} <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={authForm.username}
                  onChange={(e) => setAuthForm({...authForm, username: e.target.value})}
                  placeholder={language === 'da' ? 'Vælg et brugernavn (min. 3 tegn)' : 'Choose a username (min. 3 chars)'}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-400 focus:outline-none text-lg"
                  autoComplete="username"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {t.password} <span className="text-red-500">*</span>
                </label>
                <input
                  type="password"
                  value={authForm.password}
                  onChange={(e) => setAuthForm({...authForm, password: e.target.value})}
                  placeholder={language === 'da' ? 'Vælg en adgangskode (min. 4 tegn)' : 'Choose a password (min. 4 chars)'}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-400 focus:outline-none text-lg"
                  autoComplete={authMode === 'signup' ? 'new-password' : 'current-password'}
                />
              </div>
              {authMode === 'signup' && (
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    {t.confirmPassword} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="password"
                    value={authForm.confirmPassword}
                    onChange={(e) => setAuthForm({...authForm, confirmPassword: e.target.value})}
                    placeholder={language === 'da' ? 'Gentag din adgangskode' : 'Repeat your password'}
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-400 focus:outline-none text-lg"
                    autoComplete="new-password"
                  />
                </div>
              )}
              
              <button
                onClick={authMode === 'login' ? handleLogin : handleSignup}
                className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-4 rounded-xl hover:shadow-lg transition-all text-lg font-semibold"
              >
                {authMode === 'login' ? t.login : t.createAccount}
              </button>
              
              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white text-gray-500">
                    {language === 'da' ? 'eller' : 'or'}
                  </span>
                </div>
              </div>
              
              <button
                onClick={() => {
                  setAuthMode(authMode === 'login' ? 'signup' : 'login');
                  setAuthForm({ username: '', password: '', confirmPassword: '' });
                }}
                className="w-full border-2 border-gray-300 text-gray-700 py-3 rounded-xl hover:bg-gray-50 transition-all font-medium"
              >
                {authMode === 'login' ? (
                  <>
                    {language === 'da' ? 'Opret ny konto' : 'Create new account'}
                  </>
                ) : (
                  <>
                    {language === 'da' ? 'Har allerede en konto? Log ind' : 'Already have an account? Log in'}
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Profile Modal with Reading Lists */}
      {showProfileModal && currentUser && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl p-8 max-w-3xl w-full shadow-2xl my-8">
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center gap-3">
                <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold">
                  {currentUser.username.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="text-2xl font-serif">{t.myProfile}</h3>
                  <p className="text-gray-600">{currentUser.username}</p>
                </div>
              </div>
              <button
                onClick={() => setShowProfileModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X size={24} />
              </button>
            </div>

            {/* Reading Lists */}
            <div className="space-y-6">
              <h4 className="text-xl font-serif text-gray-900">{t.myReadingLists}</h4>
              
              {/* Want to Read */}
              <div className="bg-blue-50 rounded-2xl p-6 border border-blue-200">
                <h5 className="font-semibold text-blue-900 mb-4 flex items-center gap-2">
                  <Plus size={20} />
                  {t.wantToRead} ({readingLists.wantToRead.length})
                </h5>
                {readingLists.wantToRead.length > 0 ? (
                  <div className="space-y-2">
                    {readingLists.wantToRead.map((book, index) => (
                      <div key={index} className="flex items-center justify-between bg-white p-3 rounded-xl">
                        <div className="flex items-center gap-3">
                          {book.thumbnail && (
                            <img src={book.thumbnail} alt={book.title} className="w-10 h-14 object-cover rounded" />
                          )}
                          <div>
                            <p className="font-medium text-gray-900">{book.title}</p>
                            <p className="text-sm text-gray-600">{book.authors?.join(', ')}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => removeFromReadingList('wantToRead', book.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <X size={20} />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 text-sm">No books yet</p>
                )}
              </div>

              {/* Currently Reading */}
              <div className="bg-orange-50 rounded-2xl p-6 border border-orange-200">
                <h5 className="font-semibold text-orange-900 mb-4 flex items-center gap-2">
                  <BookOpen size={20} />
                  {t.currentlyReading} ({readingLists.currentlyReading.length})
                </h5>
                {readingLists.currentlyReading.length > 0 ? (
                  <div className="space-y-2">
                    {readingLists.currentlyReading.map((book, index) => (
                      <div key={index} className="flex items-center justify-between bg-white p-3 rounded-xl">
                        <div className="flex items-center gap-3">
                          {book.thumbnail && (
                            <img src={book.thumbnail} alt={book.title} className="w-10 h-14 object-cover rounded" />
                          )}
                          <div>
                            <p className="font-medium text-gray-900">{book.title}</p>
                            <p className="text-sm text-gray-600">{book.authors?.join(', ')}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => removeFromReadingList('currentlyReading', book.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <X size={20} />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 text-sm">No books yet</p>
                )}
              </div>

              {/* Finished */}
              <div className="bg-green-50 rounded-2xl p-6 border border-green-200">
                <h5 className="font-semibold text-green-900 mb-4 flex items-center gap-2">
                  <Star size={20} />
                  {t.finished} ({readingLists.finished.length})
                </h5>
                {readingLists.finished.length > 0 ? (
                  <div className="space-y-2">
                    {readingLists.finished.map((book, index) => (
                      <div key={index} className="flex items-center justify-between bg-white p-3 rounded-xl">
                        <div className="flex items-center gap-3">
                          {book.thumbnail && (
                            <img src={book.thumbnail} alt={book.title} className="w-10 h-14 object-cover rounded" />
                          )}
                          <div>
                            <p className="font-medium text-gray-900">{book.title}</p>
                            <p className="text-sm text-gray-600">{book.authors?.join(', ')}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => removeFromReadingList('finished', book.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <X size={20} />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 text-sm">No books yet</p>
                )}
              </div>
            </div>

            <button
              onClick={handleLogout}
              className="mt-6 w-full flex items-center justify-center gap-2 bg-red-100 text-red-700 py-3 rounded-xl hover:bg-red-200 transition-all"
            >
              <LogOut size={18} />
              {t.logout}
            </button>
          </div>
        </div>
      )}

      {/* Social Features Modal */}
      {showSocialModal && currentUser && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl p-8 max-w-3xl w-full shadow-2xl my-8">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-serif">{t.socialFeatures}</h3>
              <button
                onClick={() => setShowSocialModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X size={24} />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex gap-2 mb-6 border-b">
              <button
                onClick={() => setSocialTab('browse')}
                className={`px-4 py-2 font-medium transition-all ${
                  socialTab === 'browse'
                    ? 'text-purple-600 border-b-2 border-purple-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {t.browseUsers}
              </button>
              <button
                onClick={() => {
                  setSocialTab('activity');
                  loadRecentActivity();
                }}
                className={`px-4 py-2 font-medium transition-all ${
                  socialTab === 'activity'
                    ? 'text-purple-600 border-b-2 border-purple-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {t.activity}
              </button>
              <button
                onClick={() => {
                  console.log('Manual refresh clicked');
                  loadAllUsers();
                }}
                className="ml-auto px-4 py-2 text-sm bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-all"
                title="Opdater brugerliste"
              >
                🔄 {language === 'da' ? 'Opdater' : 'Refresh'}
              </button>
            </div>

            {/* Browse Users Tab */}
            {socialTab === 'browse' && (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {/* Debug Info */}
                <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-3 text-sm">
                  <p className="font-semibold text-yellow-800 mb-1">🔍 Debug Info:</p>
                  <p className="text-yellow-700">Totalt antal brugere: {allUsers.length}</p>
                  <p className="text-yellow-700">Brugere: {allUsers.join(', ') || 'Ingen fundet'}</p>
                  <p className="text-yellow-700">Din bruger: {currentUser.username}</p>
                  <button
                    onClick={async () => {
                      console.log('Manual sync clicked');
                      // Force reload and sync
                      const testUsernames = ['sigrid', 'alice', 'bob'];
                      const foundUsers = [];
                      
                      for (const username of testUsernames) {
                        try {
                          const user = await window.storage.get(`user:${username}`);
                          if (user && user.value) {
                            foundUsers.push(username);
                            console.log(`Found: ${username}`);
                          }
                        } catch (e) {
                          console.log(`Not found: ${username}`);
                        }
                      }
                      
                      if (foundUsers.length > 0) {
                        await window.storage.set('all-users-list', JSON.stringify(foundUsers), true);
                        console.log('Saved to global list:', foundUsers);
                        await loadAllUsers();
                        alert(`✅ Fundet ${foundUsers.length} brugere: ${foundUsers.join(', ')}`);
                      } else {
                        alert('❌ Ingen brugere fundet');
                      }
                    }}
                    className="mt-2 text-xs bg-yellow-200 text-yellow-800 px-3 py-1 rounded-lg hover:bg-yellow-300"
                  >
                    🔧 Sync Brugere (hvis tom)
                  </button>
                </div>

                <div className="grid gap-3">
                  {allUsers
                    .filter(username => username !== currentUser.username)
                    .map((username, index) => {
                      const isFollowing = following.includes(username);
                      return (
                        <div
                          key={index}
                          className="flex items-center justify-between bg-gradient-to-r from-purple-50 to-blue-50 p-4 rounded-xl border border-purple-100"
                        >
                          <div className="flex items-center gap-3">
                            <div className="bg-gradient-to-r from-purple-500 to-blue-500 text-white w-10 h-10 rounded-full flex items-center justify-center font-semibold">
                              {username.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <p className="font-semibold text-gray-900">{username}</p>
                              <p className="text-sm text-gray-600">
                                {/* Show follower count if available */}
                                {language === 'da' ? 'Bruger' : 'User'}
                              </p>
                            </div>
                          </div>
                          <button
                            onClick={() => isFollowing ? unfollowUser(username) : followUser(username)}
                            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
                              isFollowing
                                ? 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                                : 'bg-gradient-to-r from-purple-500 to-blue-500 text-white hover:shadow-lg'
                            }`}
                          >
                            {isFollowing ? (
                              <>
                                <UserX size={16} />
                                {t.unfollow}
                              </>
                            ) : (
                              <>
                                <UserCheck size={16} />
                                {t.follow}
                              </>
                            )}
                          </button>
                        </div>
                      );
                    })}
                </div>
                {allUsers.filter(u => u !== currentUser.username).length === 0 && (
                  <div className="text-center py-8">
                    <Users size={48} className="text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500 mb-4">
                      {language === 'da' ? 'Ingen andre brugere fundet' : 'No other users found'}
                    </p>
                    <button
                      onClick={loadAllUsers}
                      className="bg-purple-500 text-white px-6 py-2 rounded-xl hover:bg-purple-600 transition-all"
                    >
                      🔄 {language === 'da' ? 'Prøv igen' : 'Try again'}
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Activity Tab */}
            {socialTab === 'activity' && (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {recentActivity.length > 0 ? (
                  recentActivity.map((activity, index) => (
                    <div
                      key={index}
                      className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-xl border border-blue-100"
                    >
                      <div className="flex items-start gap-3">
                        <div className="bg-gradient-to-r from-blue-500 to-purple-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-semibold text-sm">
                          {activity.username.charAt(0).toUpperCase()}
                        </div>
                        <div className="flex-1">
                          <p className="text-gray-900">
                            <span className="font-semibold">{activity.username}</span>{' '}
                            {activity.action === 'addedToList' && (
                              <>
                                {t.addedToList} <span className="font-medium">{activity.details.bookTitle}</span> til{' '}
                                {activity.details.listName === 'wantToRead' && t.wantToRead}
                                {activity.details.listName === 'currentlyReading' && t.currentlyReading}
                                {activity.details.listName === 'finished' && t.finished}
                              </>
                            )}
                            {activity.action === 'reviewedBook' && (
                              <>
                                {t.reviewedBook} <span className="font-medium">{activity.details.bookTitle}</span>
                                {' '}({activity.details.rating} ⭐)
                              </>
                            )}
                            {activity.action === 'follow' && (
                              <>
                                {language === 'da' ? 'begyndte at følge' : 'started following'}{' '}
                                <span className="font-medium">{activity.details}</span>
                              </>
                            )}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            {new Date(activity.timestamp).toLocaleString(language === 'da' ? 'da-DK' : 'en-US')}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    {language === 'da' ? 'Ingen aktivitet endnu. Følg nogle brugere!' : 'No activity yet. Follow some users!'}
                  </div>
                )}
              </div>
            )}

            {/* Stats */}
            <div className="mt-6 pt-6 border-t grid grid-cols-2 gap-4">
              <div className="text-center">
                <p className="text-3xl font-bold text-purple-600">{following.length}</p>
                <p className="text-sm text-gray-600">{t.following}</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-blue-600">{followers.length}</p>
                <p className="text-sm text-gray-600">{t.followers}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800&family=DM+Sans:wght@400;500;600;700&display=swap');
        
        :root {
          --primary: #E91E63;
          --primary-dark: #C2185B;
          --secondary: #FF6B9D;
          --accent: #FFD54F;
          --terracotta: #D4917A;
          --cream: #FFF9F5;
          --blush: #FFE4E9;
          --charcoal: #2D2D2D;
          --soft-gray: #F5F5F5;
        }
        
        body {
          font-family: 'DM Sans', sans-serif;
          background: linear-gradient(135deg, #FFF9F5 0%, #FFE4E9 50%, #FFD4E5 100%);
          background-attachment: fixed;
        }
        
        .font-serif {
          font-family: 'Playfair Display', serif;
        }
        
        /* Glassmorphism effect */
        .glass {
          background: rgba(255, 255, 255, 0.85);
          backdrop-filter: blur(20px);
          border: 1px solid rgba(255, 255, 255, 0.5);
        }
        
        /* Glow effect for buttons */
        .glow-effect {
          box-shadow: 0 0 20px rgba(233, 30, 99, 0.3);
          transition: all 0.3s ease;
        }
        
        .glow-effect:hover {
          box-shadow: 0 0 30px rgba(233, 30, 99, 0.5);
          transform: translateY(-2px);
        }
        
        /* Decorative elements */
        .decorative-circle {
          position: absolute;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(233, 30, 99, 0.1) 0%, transparent 70%);
          pointer-events: none;
        }
        
        /* Staggered fade-in animation */
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fadeIn {
          animation: fadeInUp 0.6s ease-out;
        }
        
        .animate-delay-1 { animation-delay: 0.1s; }
        .animate-delay-2 { animation-delay: 0.2s; }
        .animate-delay-3 { animation-delay: 0.3s; }
        
        /* Card hover effects */
        .card-hover {
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .card-hover:hover {
          transform: translateY(-5px) scale(1.02);
          box-shadow: 0 20px 40px rgba(233, 30, 99, 0.15);
        }
        
        /* Gradient text */
        .gradient-text {
          background: linear-gradient(135deg, #E91E63 0%, #FF6B9D 50%, #D4917A 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar {
          width: 10px;
        }
        
        ::-webkit-scrollbar-track {
          background: #FFE4E9;
        }
        
        ::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #E91E63 0%, #FF6B9D 100%);
          border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #C2185B 0%, #E91E63 100%);
        }
        
        /* Shimmer effect for loading */
        @keyframes shimmer {
          0% { background-position: -1000px 0; }
          100% { background-position: 1000px 0; }
        }
        
        .shimmer {
          background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
          background-size: 1000px 100%;
          animation: shimmer 2s infinite;
        }
        
        /* Floating animation for decorative elements */
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
        
        .float-animation {
          animation: float 6s ease-in-out infinite;
        }
        
        /* Button press effect */
        .btn-press:active {
          transform: scale(0.95);
        }
        
        /* Focus styles */
        input:focus, textarea:focus, button:focus {
          outline: none;
          border-color: var(--primary);
          box-shadow: 0 0 0 3px rgba(233, 30, 99, 0.1);
        }
        
        /* Selection color */
        ::selection {
          background: var(--primary);
          color: white;
        }
      `}</style>
    </div>
  );
}
