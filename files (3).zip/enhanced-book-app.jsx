import React, { useState, useEffect } from 'react';
import { Book, Star, Sparkles, Info, Search, User, MessageSquare, BookMarked, List, Globe, LogIn, LogOut, Heart, TrendingUp } from 'lucide-react';

export default function BookReviewApp() {
  // Language state
  const [language, setLanguage] = useState('da');
  
  // Book search state
  const [bookTitle, setBookTitle] = useState('');
  const [loading, setLoading] = useState(false);
  const [bookData, setBookData] = useState(null);
  const [error, setError] = useState('');
  
  // Reviews state
  const [userReviews, setUserReviews] = useState([]);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [newReview, setNewReview] = useState({ rating: 5, text: '' });
  const [loadingReviews, setLoadingReviews] = useState(false);
  
  // User account state
  const [currentUser, setCurrentUser] = useState(null);
  const [showLoginForm, setShowLoginForm] = useState(false);
  const [loginName, setLoginName] = useState('');
  const [readingLists, setReadingLists] = useState({
    wantToRead: [],
    currentlyReading: [],
    read: []
  });
  const [loadingLists, setLoadingLists] = useState(false);

  // Translations
  const t = {
    da: {
      appTitle: 'Boghylden',
      appSubtitle: 'Opdag anmeldelser og fascinerende fakta om enhver bog',
      searchPlaceholder: 'Indtast en bogtitel...',
      officialRating: 'Officiel Vurdering',
      readerRating: 'Læser Vurdering',
      professionalConsensus: 'Professionel kritikerkonsensus',
      basedOn: 'Baseret på',
      review: 'anmeldelse',
      reviews: 'anmeldelser',
      noReviewsYet: 'Ingen læseranmeldelser endnu',
      officialReviews: 'Officielle Anmeldelser',
      readerReviews: 'Læser Anmeldelser',
      addYourReview: 'Tilføj Din Anmeldelse',
      shareThoughts: 'Del Dine Tanker',
      yourName: 'Dit Navn',
      enterName: 'Indtast dit navn',
      yourRating: 'Din Vurdering',
      yourReview: 'Din Anmeldelse',
      reviewPlaceholder: 'Hvad synes du om denne bog?',
      submitReview: 'Indsend Anmeldelse',
      cancel: 'Annuller',
      noReaderReviews: 'Ingen læseranmeldelser endnu. Vær den første til at dele dine tanker!',
      interestingFacts: 'Interessante Fakta',
      bookNotFound: 'Bog ikke fundet. Tjek venligst titlen og prøv igen.',
      fetchError: 'Kunne ikke hente boginformation. Prøv venligst igen.',
      enterTitle: 'Indtast en bogtitel ovenfor for at komme i gang',
      login: 'Log Ind',
      logout: 'Log Ud',
      username: 'Brugernavn',
      welcome: 'Velkommen',
      myReadingLists: 'Mine Læselister',
      wantToRead: 'Vil Læse',
      currentlyReading: 'Læser Nu',
      read: 'Læst',
      addTo: 'Tilføj til',
      removeFrom: 'Fjern fra',
      loadingReviews: 'Indlæser anmeldelser...',
      publisher: 'Udgiver',
      pages: 'Sider',
      isbn: 'ISBN',
      published: 'Udgivet',
      language: 'Sprog'
    },
    en: {
      appTitle: 'Bookshelf',
      appSubtitle: 'Discover reviews and fascinating facts about any book',
      searchPlaceholder: 'Enter a book title...',
      officialRating: 'Official Rating',
      readerRating: 'Reader Rating',
      professionalConsensus: 'Professional critics consensus',
      basedOn: 'Based on',
      review: 'review',
      reviews: 'reviews',
      noReviewsYet: 'No reader reviews yet',
      officialReviews: 'Official Reviews',
      readerReviews: 'Reader Reviews',
      addYourReview: 'Add Your Review',
      shareThoughts: 'Share Your Thoughts',
      yourName: 'Your Name',
      enterName: 'Enter your name',
      yourRating: 'Your Rating',
      yourReview: 'Your Review',
      reviewPlaceholder: 'What did you think about this book?',
      submitReview: 'Submit Review',
      cancel: 'Cancel',
      noReaderReviews: 'No reader reviews yet. Be the first to share your thoughts!',
      interestingFacts: 'Interesting Facts',
      bookNotFound: 'Book not found. Please check the title and try again.',
      fetchError: 'Failed to fetch book information. Please try again.',
      enterTitle: 'Enter a book title above to get started',
      login: 'Log In',
      logout: 'Log Out',
      username: 'Username',
      welcome: 'Welcome',
      myReadingLists: 'My Reading Lists',
      wantToRead: 'Want to Read',
      currentlyReading: 'Currently Reading',
      read: 'Read',
      addTo: 'Add to',
      removeFrom: 'Remove from',
      loadingReviews: 'Loading reviews...',
      publisher: 'Publisher',
      pages: 'Pages',
      isbn: 'ISBN',
      published: 'Published',
      language: 'Language'
    }
  };

  // Load user session on mount
  useEffect(() => {
    loadUserSession();
  }, []);

  // Load user's reading lists when user logs in
  useEffect(() => {
    if (currentUser) {
      loadReadingLists();
    }
  }, [currentUser]);

  const loadUserSession = async () => {
    try {
      const result = await window.storage.get('current-user', false);
      if (result && result.value) {
        setCurrentUser(JSON.parse(result.value));
      }
    } catch (err) {
      console.log('No user session found');
    }
  };

  const handleLogin = async () => {
    if (!loginName.trim()) return;
    
    const user = { username: loginName.trim(), loginDate: new Date().toISOString() };
    await window.storage.set('current-user', JSON.stringify(user), false);
    setCurrentUser(user);
    setShowLoginForm(false);
    setLoginName('');
  };

  const handleLogout = async () => {
    await window.storage.delete('current-user', false);
    setCurrentUser(null);
    setReadingLists({ wantToRead: [], currentlyReading: [], read: [] });
  };

  const loadReadingLists = async () => {
    if (!currentUser) return;
    
    setLoadingLists(true);
    try {
      const result = await window.storage.get(`reading-lists:${currentUser.username}`, false);
      if (result && result.value) {
        setReadingLists(JSON.parse(result.value));
      }
    } catch (err) {
      console.log('No reading lists found');
    } finally {
      setLoadingLists(false);
    }
  };

  const addToReadingList = async (listName, book) => {
    if (!currentUser) {
      alert(language === 'da' ? 'Log venligst ind for at gemme bøger' : 'Please log in to save books');
      return;
    }

    const newLists = { ...readingLists };
    
    // Remove from other lists if present
    Object.keys(newLists).forEach(key => {
      newLists[key] = newLists[key].filter(b => b.isbn !== book.isbn);
    });
    
    // Add to selected list
    if (!newLists[listName].find(b => b.isbn === book.isbn)) {
      newLists[listName].push({
        isbn: book.isbn,
        title: book.title,
        author: book.author,
        thumbnail: book.thumbnail,
        addedDate: new Date().toISOString()
      });
    }

    await window.storage.set(`reading-lists:${currentUser.username}`, JSON.stringify(newLists), false);
    setReadingLists(newLists);
  };

  const removeFromReadingList = async (listName, isbn) => {
    const newLists = { ...readingLists };
    newLists[listName] = newLists[listName].filter(b => b.isbn !== isbn);
    
    await window.storage.set(`reading-lists:${currentUser.username}`, JSON.stringify(newLists), false);
    setReadingLists(newLists);
  };

  const isInList = (listName) => {
    if (!bookData) return false;
    return readingLists[listName].some(b => b.isbn === bookData.isbn);
  };

  const fetchBookInfo = async (title) => {
    setLoading(true);
    setError('');
    setBookData(null);

    try {
      // First, get real book data from Google Books API
      const googleBooksResponse = await fetch(
        `https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(title)}&maxResults=1`
      );
      const googleData = await googleBooksResponse.json();

      if (!googleData.items || googleData.items.length === 0) {
        setError(t[language].bookNotFound);
        setLoading(false);
        return;
      }

      const bookInfo = googleData.items[0].volumeInfo;
      const industryIdentifiers = bookInfo.industryIdentifiers || [];
      const isbn = industryIdentifiers.find(id => id.type === 'ISBN_13')?.identifier || 
                   industryIdentifiers.find(id => id.type === 'ISBN_10')?.identifier || 
                   'N/A';

      // Now get AI-generated reviews and facts
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [
            {
              role: "user",
              content: `Please provide professional reviews and interesting facts about the book "${bookInfo.title}" by ${bookInfo.authors?.join(', ') || 'Unknown'} in ${language === 'da' ? 'Danish' : 'English'}. Return ONLY valid JSON with no markdown formatting:

{
  "officialRating": 4.5,
  "reviews": [
    {
      "reviewer": "publication name",
      "rating": 5,
      "text": "review text"
    }
  ],
  "facts": [
    "interesting fact 1",
    "interesting fact 2",
    "interesting fact 3"
  ]
}

If you don't know this book, use: {"officialRating": 0, "reviews": [], "facts": []}`
            }
          ],
        })
      });

      const aiData = await response.json();
      const text = aiData.content
        .map(item => (item.type === "text" ? item.text : ""))
        .filter(Boolean)
        .join("\n");

      const cleanText = text.replace(/```json|```/g, "").trim();
      const aiParsed = JSON.parse(cleanText);

      // Combine real book data with AI reviews
      const combinedData = {
        title: bookInfo.title,
        author: bookInfo.authors?.join(', ') || 'Unknown',
        publicationYear: bookInfo.publishedDate?.split('-')[0] || 'N/A',
        publisher: bookInfo.publisher || 'N/A',
        pageCount: bookInfo.pageCount || 'N/A',
        language: bookInfo.language || 'N/A',
        isbn: isbn,
        genre: bookInfo.categories?.[0] || 'Fiction',
        summary: bookInfo.description || 'No description available',
        thumbnail: bookInfo.imageLinks?.thumbnail || '',
        rating: aiParsed.officialRating || 0,
        reviews: aiParsed.reviews || [],
        facts: aiParsed.facts || []
      };

      setBookData(combinedData);
      await loadUserReviews(isbn);
    } catch (err) {
      console.error('Error:', err);
      setError(t[language].fetchError);
    } finally {
      setLoading(false);
    }
  };

  const loadUserReviews = async (isbn) => {
    setLoadingReviews(true);
    try {
      const result = await window.storage.get(`user-reviews:${isbn}`, true);
      if (result && result.value) {
        setUserReviews(JSON.parse(result.value));
      } else {
        setUserReviews([]);
      }
    } catch (err) {
      console.log('No existing reviews found');
      setUserReviews([]);
    } finally {
      setLoadingReviews(false);
    }
  };

  const saveUserReview = async () => {
    if (!currentUser) {
      alert(language === 'da' ? 'Log venligst ind for at skrive en anmeldelse' : 'Please log in to write a review');
      return;
    }

    if (!newReview.text.trim()) {
      alert(language === 'da' ? 'Udfyld venligst alle felter' : 'Please fill in all fields');
      return;
    }

    try {
      const updatedReviews = [...userReviews, {
        username: currentUser.username,
        rating: newReview.rating,
        text: newReview.text,
        date: new Date().toISOString()
      }];
      
      await window.storage.set(`user-reviews:${bookData.isbn}`, JSON.stringify(updatedReviews), true);
      setUserReviews(updatedReviews);
      setNewReview({ rating: 5, text: '' });
      setShowReviewForm(false);
    } catch (err) {
      console.error('Error saving review:', err);
      alert(t[language].fetchError);
    }
  };

  const calculateUserRating = () => {
    if (userReviews.length === 0) return 0;
    const sum = userReviews.reduce((acc, review) => acc + review.rating, 0);
    return (sum / userReviews.length).toFixed(1);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (bookTitle.trim()) {
      fetchBookInfo(bookTitle.trim());
    }
  };

  const renderStars = (rating, whiteStars = false) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    return (
      <div className="flex gap-1">
        {[...Array(5)].map((_, i) => {
          if (i < fullStars) {
            return (
              <Star
                key={i}
                size={20}
                className={whiteStars ? "fill-white text-white" : "fill-amber-400 text-amber-400"}
              />
            );
          } else if (i === fullStars && hasHalfStar) {
            return (
              <div key={i} className="relative">
                <Star
                  size={20}
                  className={whiteStars ? "text-white/30" : "text-gray-300"}
                />
                <div className="absolute inset-0 overflow-hidden" style={{width: '50%'}}>
                  <Star
                    size={20}
                    className={whiteStars ? "fill-white text-white" : "fill-amber-400 text-amber-400"}
                  />
                </div>
              </div>
            );
          } else {
            return (
              <Star
                key={i}
                size={20}
                className={whiteStars ? "text-white/30" : "text-gray-300"}
              />
            );
          }
        })}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-rose-50 to-purple-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header with Language Toggle and Login */}
        <div className="flex justify-between items-start mb-8 pt-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setLanguage(language === 'da' ? 'en' : 'da')}
              className="flex items-center gap-2 bg-white/80 backdrop-blur px-4 py-2 rounded-xl border-2 border-rose-200 hover:border-rose-400 transition-all"
            >
              <Globe size={18} />
              <span className="font-medium">{language === 'da' ? 'DA' : 'EN'}</span>
            </button>
          </div>
          
          <div>
            {currentUser ? (
              <div className="flex items-center gap-3">
                <div className="bg-white/80 backdrop-blur px-4 py-2 rounded-xl border-2 border-purple-200">
                  <div className="flex items-center gap-2">
                    <User size={18} className="text-purple-600" />
                    <span className="font-medium">{currentUser.username}</span>
                  </div>
                </div>
                <button
                  onClick={handleLogout}
                  className="flex items-center gap-2 bg-gradient-to-r from-rose-500 to-purple-600 text-white px-4 py-2 rounded-xl hover:shadow-lg transition-all"
                >
                  <LogOut size={18} />
                  {t[language].logout}
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowLoginForm(true)}
                className="flex items-center gap-2 bg-gradient-to-r from-rose-500 to-purple-600 text-white px-4 py-2 rounded-xl hover:shadow-lg transition-all"
              >
                <LogIn size={18} />
                {t[language].login}
              </button>
            )}
          </div>
        </div>

        {/* Login Modal */}
        {showLoginForm && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl">
              <h3 className="text-2xl font-serif mb-6">{t[language].login}</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {t[language].username}
                  </label>
                  <input
                    type="text"
                    value={loginName}
                    onChange={(e) => setLoginName(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                    placeholder={t[language].enterName}
                    className="w-full px-4 py-2 rounded-xl border-2 border-gray-200 focus:border-purple-400 focus:outline-none"
                  />
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={handleLogin}
                    className="flex-1 bg-gradient-to-r from-rose-500 to-purple-600 text-white px-6 py-2 rounded-xl hover:shadow-lg transition-all"
                  >
                    {t[language].login}
                  </button>
                  <button
                    onClick={() => {
                      setShowLoginForm(false);
                      setLoginName('');
                    }}
                    className="flex-1 bg-gray-200 text-gray-700 px-6 py-2 rounded-xl hover:bg-gray-300 transition-all"
                  >
                    {t[language].cancel}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* App Title */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-3 mb-4">
            <Book size={48} className="text-rose-600" strokeWidth={1.5} />
            <h1 className="text-6xl font-serif italic text-gray-900">{t[language].appTitle}</h1>
          </div>
          <p className="text-gray-600 text-lg font-light">{t[language].appSubtitle}</p>
        </div>

        {/* Search Form */}
        <form onSubmit={handleSubmit} className="mb-12">
          <div className="relative">
            <input
              type="text"
              value={bookTitle}
              onChange={(e) => setBookTitle(e.target.value)}
              placeholder={t[language].searchPlaceholder}
              className="w-full px-6 py-4 pr-14 text-lg rounded-2xl border-2 border-rose-200 focus:border-rose-400 focus:outline-none bg-white/80 backdrop-blur shadow-lg placeholder:text-gray-400"
            />
            <button
              type="submit"
              disabled={loading || !bookTitle.trim()}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-gradient-to-r from-rose-500 to-purple-600 text-white p-3 rounded-xl hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 hover:scale-105"
            >
              {loading ? (
                <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div>
              ) : (
                <Search size={20} />
              )}
            </button>
          </div>
        </form>

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border-2 border-red-200 text-red-700 px-6 py-4 rounded-2xl mb-8">
            {error}
          </div>
        )}

        {/* Book Information */}
        {bookData && (
          <div className="space-y-8 animate-fadeIn">
            {/* Book Header */}
            <div className="bg-white/90 backdrop-blur rounded-3xl p-8 shadow-xl border-2 border-rose-100">
              <div className="flex items-start gap-6">
                {bookData.thumbnail && (
                  <img 
                    src={bookData.thumbnail} 
                    alt={bookData.title}
                    className="w-32 h-48 object-cover rounded-xl shadow-lg"
                  />
                )}
                <div className="flex-1">
                  <h2 className="text-4xl font-serif mb-2 text-gray-900">{bookData.title}</h2>
                  <p className="text-xl text-gray-600 mb-3">{t[language].by || 'by'} {bookData.author}</p>
                  <div className="flex flex-wrap items-center gap-3 text-sm text-gray-500 mb-4">
                    <span className="bg-rose-100 px-3 py-1 rounded-full">{bookData.genre}</span>
                    <span>{bookData.publicationYear}</span>
                    <span>{bookData.pageCount} {t[language].pages}</span>
                  </div>
                  
                  {/* Reading List Buttons */}
                  {currentUser && (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {isInList('wantToRead') ? (
                        <button
                          onClick={() => removeFromReadingList('wantToRead', bookData.isbn)}
                          className="text-sm bg-green-100 text-green-700 px-3 py-1 rounded-full hover:bg-green-200 transition-all"
                        >
                          ✓ {t[language].wantToRead}
                        </button>
                      ) : (
                        <button
                          onClick={() => addToReadingList('wantToRead', bookData)}
                          className="text-sm bg-gray-100 text-gray-700 px-3 py-1 rounded-full hover:bg-gray-200 transition-all"
                        >
                          + {t[language].wantToRead}
                        </button>
                      )}
                      
                      {isInList('currentlyReading') ? (
                        <button
                          onClick={() => removeFromReadingList('currentlyReading', bookData.isbn)}
                          className="text-sm bg-blue-100 text-blue-700 px-3 py-1 rounded-full hover:bg-blue-200 transition-all"
                        >
                          ✓ {t[language].currentlyReading}
                        </button>
                      ) : (
                        <button
                          onClick={() => addToReadingList('currentlyReading', bookData)}
                          className="text-sm bg-gray-100 text-gray-700 px-3 py-1 rounded-full hover:bg-gray-200 transition-all"
                        >
                          + {t[language].currentlyReading}
                        </button>
                      )}
                      
                      {isInList('read') ? (
                        <button
                          onClick={() => removeFromReadingList('read', bookData.isbn)}
                          className="text-sm bg-purple-100 text-purple-700 px-3 py-1 rounded-full hover:bg-purple-200 transition-all"
                        >
                          ✓ {t[language].read}
                        </button>
                      ) : (
                        <button
                          onClick={() => addToReadingList('read', bookData)}
                          className="text-sm bg-gray-100 text-gray-700 px-3 py-1 rounded-full hover:bg-gray-200 transition-all"
                        >
                          + {t[language].read}
                        </button>
                      )}
                    </div>
                  )}

                  {/* Ratings Display */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                    {/* Official Rating Card */}
                    <div className="relative overflow-hidden bg-gradient-to-br from-amber-500 to-orange-600 p-6 rounded-2xl shadow-lg transform transition-transform hover:scale-105">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                      <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
                      <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-3">
                          <Star className="text-white fill-white" size={20} />
                          <p className="text-sm font-bold text-white/90 tracking-wide uppercase">{t[language].officialRating}</p>
                        </div>
                        <div className="flex items-end gap-3 mb-3">
                          <span className="text-6xl font-bold text-white leading-none">{bookData.rating}</span>
                          <span className="text-2xl text-white/80 pb-2">/5</span>
                        </div>
                        <div className="flex gap-1">
                          {renderStars(bookData.rating, true)}
                        </div>
                        <p className="text-white/70 text-sm mt-3">{t[language].professionalConsensus}</p>
                      </div>
                    </div>

                    {/* Reader Rating Card */}
                    <div className="relative overflow-hidden bg-gradient-to-br from-blue-500 to-purple-600 p-6 rounded-2xl shadow-lg transform transition-transform hover:scale-105">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                      <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
                      <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-3">
                          <User className="text-white" size={20} />
                          <p className="text-sm font-bold text-white/90 tracking-wide uppercase">{t[language].readerRating}</p>
                        </div>
                        {userReviews.length > 0 ? (
                          <>
                            <div className="flex items-end gap-3 mb-3">
                              <span className="text-6xl font-bold text-white leading-none">{calculateUserRating()}</span>
                              <span className="text-2xl text-white/80 pb-2">/5</span>
                            </div>
                            <div className="flex gap-1">
                              {renderStars(parseFloat(calculateUserRating()), true)}
                            </div>
                            <p className="text-white/70 text-sm mt-3">
                              {t[language].basedOn} {userReviews.length} {userReviews.length === 1 ? t[language].review : t[language].reviews}
                            </p>
                          </>
                        ) : (
                          <>
                            <div className="flex items-end gap-3 mb-3">
                              <span className="text-6xl font-bold text-white/50 leading-none">--</span>
                              <span className="text-2xl text-white/50 pb-2">/5</span>
                            </div>
                            <div className="flex gap-1">
                              {renderStars(0, true)}
                            </div>
                            <p className="text-white/70 text-sm mt-3">{t[language].noReviewsYet}</p>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <p className="mt-6 text-gray-700 leading-relaxed text-lg">{bookData.summary}</p>
              
              {/* Book Details */}
              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <p className="text-gray-500 mb-1">{t[language].publisher}</p>
                    <p className="font-medium">{bookData.publisher}</p>
                  </div>
                  <div>
                    <p className="text-gray-500 mb-1">{t[language].isbn}</p>
                    <p className="font-medium">{bookData.isbn}</p>
                  </div>
                  <div>
                    <p className="text-gray-500 mb-1">{t[language].pages}</p>
                    <p className="font-medium">{bookData.pageCount}</p>
                  </div>
                  <div>
                    <p className="text-gray-500 mb-1">{t[language].language}</p>
                    <p className="font-medium">{bookData.language.toUpperCase()}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Official Reviews Section */}
            {bookData.reviews && bookData.reviews.length > 0 && (
              <div className="bg-white/90 backdrop-blur rounded-3xl p-8 shadow-xl border-2 border-purple-100">
                <div className="flex items-center gap-3 mb-6">
                  <Star className="text-amber-500" size={28} />
                  <h3 className="text-3xl font-serif text-gray-900">{t[language].officialReviews}</h3>
                </div>
                <div className="space-y-4">
                  {bookData.reviews.map((review, index) => (
                    <div
                      key={index}
                      className="bg-gradient-to-r from-purple-50 to-rose-50 p-6 rounded-2xl border border-purple-100"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-semibold text-gray-800">{review.reviewer}</span>
                        <div className="flex gap-1">
                          {renderStars(review.rating)}
                        </div>
                      </div>
                      <p className="text-gray-700 leading-relaxed">{review.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* User Reviews Section */}
            <div className="bg-white/90 backdrop-blur rounded-3xl p-8 shadow-xl border-2 border-blue-100">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <MessageSquare className="text-blue-500" size={28} />
                  <h3 className="text-3xl font-serif text-gray-900">{t[language].readerReviews}</h3>
                </div>
                <button
                  onClick={() => {
                    if (!currentUser) {
                      setShowLoginForm(true);
                    } else {
                      setShowReviewForm(!showReviewForm);
                    }
                  }}
                  className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-xl hover:shadow-lg transition-all duration-300 hover:scale-105 flex items-center gap-2"
                >
                  <User size={18} />
                  {t[language].addYourReview}
                </button>
              </div>

              {/* Review Form */}
              {showReviewForm && currentUser && (
                <div className="mb-6 bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-2xl border-2 border-blue-200">
                  <h4 className="font-semibold text-gray-800 mb-4">{t[language].shareThoughts}</h4>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">{t[language].yourRating}</label>
                      <div className="flex gap-2">
                        {[1, 2, 3, 4, 5].map((rating) => (
                          <button
                            key={rating}
                            type="button"
                            onClick={() => setNewReview({...newReview, rating})}
                            className="focus:outline-none transition-transform hover:scale-110"
                          >
                            <Star
                              size={32}
                              className={rating <= newReview.rating ? "fill-amber-400 text-amber-400" : "text-gray-300"}
                            />
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">{t[language].yourReview}</label>
                      <textarea
                        value={newReview.text}
                        onChange={(e) => setNewReview({...newReview, text: e.target.value})}
                        placeholder={t[language].reviewPlaceholder}
                        rows="4"
                        className="w-full px-4 py-2 rounded-xl border border-blue-200 focus:border-blue-400 focus:outline-none resize-none"
                      />
                    </div>
                    <div className="flex gap-3">
                      <button
                        onClick={saveUserReview}
                        className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-xl hover:shadow-lg transition-all"
                      >
                        {t[language].submitReview}
                      </button>
                      <button
                        onClick={() => {
                          setShowReviewForm(false);
                          setNewReview({ rating: 5, text: '' });
                        }}
                        className="bg-gray-200 text-gray-700 px-6 py-2 rounded-xl hover:bg-gray-300 transition-all"
                      >
                        {t[language].cancel}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* User Reviews List */}
              {loadingReviews ? (
                <div className="text-center py-8 text-gray-500">{t[language].loadingReviews}</div>
              ) : userReviews.length > 0 ? (
                <div className="space-y-4">
                  {userReviews.map((review, index) => (
                    <div
                      key={index}
                      className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-2xl border border-blue-100"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <div className="bg-blue-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-semibold">
                            {review.username.charAt(0).toUpperCase()}
                          </div>
                          <span className="font-semibold text-gray-800">{review.username}</span>
                        </div>
                        <div className="flex gap-1">
                          {renderStars(review.rating)}
                        </div>
                      </div>
                      <p className="text-gray-700 leading-relaxed">{review.text}</p>
                      <p className="text-xs text-gray-500 mt-2">
                        {new Date(review.date).toLocaleDateString(language === 'da' ? 'da-DK' : 'en-US')}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <User size={48} className="text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">{t[language].noReaderReviews}</p>
                </div>
              )}
            </div>

            {/* Facts Section */}
            {bookData.facts && bookData.facts.length > 0 && (
              <div className="bg-white/90 backdrop-blur rounded-3xl p-8 shadow-xl border-2 border-orange-100">
                <div className="flex items-center gap-3 mb-6">
                  <Sparkles className="text-orange-500" size={28} />
                  <h3 className="text-3xl font-serif text-gray-900">{t[language].interestingFacts}</h3>
                </div>
                <div className="space-y-3">
                  {bookData.facts.map((fact, index) => (
                    <div
                      key={index}
                      className="flex items-start gap-4 bg-gradient-to-r from-orange-50 to-rose-50 p-5 rounded-2xl border border-orange-100"
                    >
                      <Info className="text-orange-500 mt-1 flex-shrink-0" size={20} />
                      <p className="text-gray-700 leading-relaxed">{fact}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Reading Lists Sidebar (when user is logged in and no book is displayed) */}
        {currentUser && !bookData && !loading && (
          <div className="bg-white/90 backdrop-blur rounded-3xl p-8 shadow-xl border-2 border-purple-100">
            <div className="flex items-center gap-3 mb-6">
              <BookMarked className="text-purple-500" size={28} />
              <h3 className="text-3xl font-serif text-gray-900">{t[language].myReadingLists}</h3>
            </div>
            
            <div className="space-y-6">
              {/* Want to Read */}
              <div>
                <h4 className="font-semibold text-lg mb-3 flex items-center gap-2">
                  <Heart size={20} className="text-rose-500" />
                  {t[language].wantToRead} ({readingLists.wantToRead.length})
                </h4>
                {readingLists.wantToRead.length > 0 ? (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {readingLists.wantToRead.map((book, idx) => (
                      <div key={idx} className="bg-gradient-to-br from-rose-50 to-orange-50 p-3 rounded-xl border border-rose-200">
                        {book.thumbnail && (
                          <img src={book.thumbnail} alt={book.title} className="w-full h-32 object-cover rounded-lg mb-2" />
                        )}
                        <p className="text-sm font-semibold line-clamp-2">{book.title}</p>
                        <p className="text-xs text-gray-600 line-clamp-1">{book.author}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 text-sm">{language === 'da' ? 'Ingen bøger endnu' : 'No books yet'}</p>
                )}
              </div>

              {/* Currently Reading */}
              <div>
                <h4 className="font-semibold text-lg mb-3 flex items-center gap-2">
                  <TrendingUp size={20} className="text-blue-500" />
                  {t[language].currentlyReading} ({readingLists.currentlyReading.length})
                </h4>
                {readingLists.currentlyReading.length > 0 ? (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {readingLists.currentlyReading.map((book, idx) => (
                      <div key={idx} className="bg-gradient-to-br from-blue-50 to-purple-50 p-3 rounded-xl border border-blue-200">
                        {book.thumbnail && (
                          <img src={book.thumbnail} alt={book.title} className="w-full h-32 object-cover rounded-lg mb-2" />
                        )}
                        <p className="text-sm font-semibold line-clamp-2">{book.title}</p>
                        <p className="text-xs text-gray-600 line-clamp-1">{book.author}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 text-sm">{language === 'da' ? 'Ingen bøger endnu' : 'No books yet'}</p>
                )}
              </div>

              {/* Read */}
              <div>
                <h4 className="font-semibold text-lg mb-3 flex items-center gap-2">
                  <BookMarked size={20} className="text-purple-500" />
                  {t[language].read} ({readingLists.read.length})
                </h4>
                {readingLists.read.length > 0 ? (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {readingLists.read.map((book, idx) => (
                      <div key={idx} className="bg-gradient-to-br from-purple-50 to-pink-50 p-3 rounded-xl border border-purple-200">
                        {book.thumbnail && (
                          <img src={book.thumbnail} alt={book.title} className="w-full h-32 object-cover rounded-lg mb-2" />
                        )}
                        <p className="text-sm font-semibold line-clamp-2">{book.title}</p>
                        <p className="text-xs text-gray-600 line-clamp-1">{book.author}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 text-sm">{language === 'da' ? 'Ingen bøger endnu' : 'No books yet'}</p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Initial State */}
        {!bookData && !loading && !error && !currentUser && (
          <div className="text-center py-16">
            <div className="inline-block p-8 bg-white/60 backdrop-blur rounded-3xl border-2 border-dashed border-rose-200">
              <Book size={64} className="text-rose-300 mx-auto mb-4" strokeWidth={1.5} />
              <p className="text-gray-500 text-lg">{t[language].enterTitle}</p>
            </div>
          </div>
        )}
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Crimson+Text:ital,wght@0,400;0,600;1,400&family=Inter:wght@300;400;500;600&display=swap');
        
        body {
          font-family: 'Inter', sans-serif;
        }
        
        .font-serif {
          font-family: 'Crimson Text', serif;
        }
        
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.6s ease-out;
        }

        .line-clamp-1 {
          display: -webkit-box;
          -webkit-line-clamp: 1;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </div>
  );
}
