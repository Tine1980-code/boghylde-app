// DEBUG SCRIPT - Kør dette i browser console (F12)
// Dette script tjekker om brugerne eksisterer og fikser brugerlisten

async function debugUsers() {
  console.log('=== DEBUGGING BRUGERE ===');
  
  // Test 1: Check om Sigrid eksisterer
  try {
    const sigrid = await window.storage.get('user:sigrid');
    console.log('✅ Sigrid findes:', sigrid);
  } catch (err) {
    console.log('❌ Sigrid findes IKKE:', err.message);
  }
  
  // Test 2: Check om Alice eksisterer
  try {
    const alice = await window.storage.get('user:alice');
    console.log('✅ Alice findes:', alice);
  } catch (err) {
    console.log('❌ Alice findes IKKE:', err.message);
  }
  
  // Test 3: Check om Bob eksisterer
  try {
    const bob = await window.storage.get('user:bob');
    console.log('✅ Bob findes:', bob);
  } catch (err) {
    console.log('❌ Bob findes IKKE:', err.message);
  }
  
  // Test 4: List alle keys der starter med 'user:'
  try {
    const result = await window.storage.list('user:', true);
    console.log('📋 Alle user: keys:', result);
  } catch (err) {
    console.log('❌ Kunne ikke liste keys:', err.message);
  }
  
  // Test 5: Check global brugerliste
  try {
    const usersList = await window.storage.get('all-users-list', true);
    console.log('📝 Global brugerliste:', usersList);
  } catch (err) {
    console.log('❌ Ingen global brugerliste:', err.message);
  }
  
  console.log('=== DEBUG FÆRDIG ===');
  console.log('Kopier alt output og send til mig!');
}

// Kør debug
debugUsers();

// Hvis Alice og Bob IKKE eksisterer, opret dem her:
async function createMissingUsers() {
  console.log('=== OPRETTER MANGLENDE BRUGERE ===');
  
  const usersToCreate = [
    { username: 'alice', password: '1234' },
    { username: 'bob', password: '1234' }
  ];
  
  for (const userData of usersToCreate) {
    try {
      // Check om bruger allerede eksisterer
      const existing = await window.storage.get(`user:${userData.username}`);
      console.log(`${userData.username} eksisterer allerede`);
    } catch (err) {
      // Bruger eksisterer ikke - opret den
      const newUser = {
        username: userData.username,
        password: userData.password,
        createdAt: new Date().toISOString()
      };
      
      await window.storage.set(`user:${userData.username}`, JSON.stringify(newUser), true);
      console.log(`✅ ${userData.username} oprettet!`);
      
      // Initialiser lists
      await window.storage.set(`reading-lists:${userData.username}`, JSON.stringify({
        wantToRead: [],
        currentlyReading: [],
        finished: []
      }));
      
      await window.storage.set(`following:${userData.username}`, JSON.stringify([]), true);
      await window.storage.set(`followers:${userData.username}`, JSON.stringify([]), true);
    }
  }
  
  // Opdater global liste
  const allUsers = ['sigrid', 'alice', 'bob'];
  await window.storage.set('all-users-list', JSON.stringify(allUsers), true);
  console.log('✅ Global brugerliste opdateret:', allUsers);
  
  console.log('=== OPRETTELSE FÆRDIG ===');
  console.log('Refresh siden nu!');
}

// Kommenter IKKE denne linje ud medmindre debug viser at Alice og Bob mangler:
// createMissingUsers();
