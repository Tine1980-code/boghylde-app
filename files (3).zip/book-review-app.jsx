import React, { useState, useEffect } from 'react';
import { Book, Star, Sparkles, Info, Search, User, MessageSquare } from 'lucide-react';

export default function BookReviewApp() {
  const [bookTitle, setBookTitle] = useState('');
  const [loading, setLoading] = useState(false);
  const [bookData, setBookData] = useState(null);
  const [error, setError] = useState('');
  const [userReviews, setUserReviews] = useState([]);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [newReview, setNewReview] = useState({ name: '', rating: 5, text: '' });
  const [loadingReviews, setLoadingReviews] = useState(false);

  const fetchBookInfo = async (title) => {
    setLoading(true);
    setError('');
    setBookData(null);

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [
            {
              role: "user",
              content: `Please provide information about the book "${title}" in the following JSON format. Return ONLY valid JSON with no markdown formatting, no backticks, and no preamble:

{
  "title": "exact book title",
  "author": "author name",
  "publicationYear": "year",
  "genre": "primary genre",
  "rating": 4.5,
  "summary": "2-3 sentence summary",
  "reviews": [
    {
      "reviewer": "reviewer name or publication",
      "rating": 5,
      "text": "review text"
    }
  ],
  "facts": [
    "interesting fact 1",
    "interesting fact 2",
    "interesting fact 3"
  ]
}

If you don't know this book, respond with: {"error": "Book not found"}`
            }
          ],
        })
      });

      const data = await response.json();
      const text = data.content
        .map(item => (item.type === "text" ? item.text : ""))
        .filter(Boolean)
        .join("\n");

      const cleanText = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(cleanText);

      if (parsed.error) {
        setError('Book not found. Please check the title and try again.');
      } else {
        setBookData(parsed);
        await loadUserReviews(parsed.title);
      }
    } catch (err) {
      console.error('Error:', err);
      setError('Failed to fetch book information. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const loadUserReviews = async (bookTitle) => {
    setLoadingReviews(true);
    try {
      const normalizedTitle = bookTitle.toLowerCase().replace(/[^a-z0-9]/g, '-');
      const result = await window.storage.get(`reviews:${normalizedTitle}`, true);
      if (result && result.value) {
        setUserReviews(JSON.parse(result.value));
      } else {
        setUserReviews([]);
      }
    } catch (err) {
      console.log('No existing reviews found');
      setUserReviews([]);
    } finally {
      setLoadingReviews(false);
    }
  };

  const saveUserReview = async () => {
    if (!newReview.name.trim() || !newReview.text.trim()) {
      alert('Please fill in all fields');
      return;
    }

    try {
      const normalizedTitle = bookData.title.toLowerCase().replace(/[^a-z0-9]/g, '-');
      const updatedReviews = [...userReviews, {
        ...newReview,
        date: new Date().toISOString()
      }];
      
      await window.storage.set(`reviews:${normalizedTitle}`, JSON.stringify(updatedReviews), true);
      setUserReviews(updatedReviews);
      setNewReview({ name: '', rating: 5, text: '' });
      setShowReviewForm(false);
    } catch (err) {
      console.error('Error saving review:', err);
      alert('Failed to save review. Please try again.');
    }
  };

  const calculateUserRating = () => {
    if (userReviews.length === 0) return 0;
    const sum = userReviews.reduce((acc, review) => acc + review.rating, 0);
    return (sum / userReviews.length).toFixed(1);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (bookTitle.trim()) {
      fetchBookInfo(bookTitle.trim());
    }
  };

  const renderStars = (rating, whiteStars = false) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    return (
      <div className="flex gap-1">
        {[...Array(5)].map((_, i) => {
          if (i < fullStars) {
            return (
              <Star
                key={i}
                size={20}
                className={whiteStars ? "fill-white text-white" : "fill-amber-400 text-amber-400"}
              />
            );
          } else if (i === fullStars && hasHalfStar) {
            return (
              <div key={i} className="relative">
                <Star
                  size={20}
                  className={whiteStars ? "text-white/30" : "text-gray-300"}
                />
                <div className="absolute inset-0 overflow-hidden" style={{width: '50%'}}>
                  <Star
                    size={20}
                    className={whiteStars ? "fill-white text-white" : "fill-amber-400 text-amber-400"}
                  />
                </div>
              </div>
            );
          } else {
            return (
              <Star
                key={i}
                size={20}
                className={whiteStars ? "text-white/30" : "text-gray-300"}
              />
            );
          }
        })}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-rose-50 to-purple-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12 pt-8">
          <div className="inline-flex items-center gap-3 mb-4">
            <Book size={48} className="text-rose-600" strokeWidth={1.5} />
            <h1 className="text-6xl font-serif italic text-gray-900">Bookshelf</h1>
          </div>
          <p className="text-gray-600 text-lg font-light">Discover reviews and fascinating facts about any book</p>
        </div>

        {/* Search Form */}
        <form onSubmit={handleSubmit} className="mb-12">
          <div className="relative">
            <input
              type="text"
              value={bookTitle}
              onChange={(e) => setBookTitle(e.target.value)}
              placeholder="Enter a book title..."
              className="w-full px-6 py-4 pr-14 text-lg rounded-2xl border-2 border-rose-200 focus:border-rose-400 focus:outline-none bg-white/80 backdrop-blur shadow-lg placeholder:text-gray-400"
            />
            <button
              type="submit"
              disabled={loading || !bookTitle.trim()}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-gradient-to-r from-rose-500 to-purple-600 text-white p-3 rounded-xl hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 hover:scale-105"
            >
              {loading ? (
                <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div>
              ) : (
                <Search size={20} />
              )}
            </button>
          </div>
        </form>

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border-2 border-red-200 text-red-700 px-6 py-4 rounded-2xl mb-8">
            {error}
          </div>
        )}

        {/* Book Information */}
        {bookData && (
          <div className="space-y-8 animate-fadeIn">
            {/* Book Header */}
            <div className="bg-white/90 backdrop-blur rounded-3xl p-8 shadow-xl border-2 border-rose-100">
              <div className="flex items-start gap-6">
                <div className="bg-gradient-to-br from-rose-500 to-purple-600 p-6 rounded-2xl shadow-lg">
                  <Book size={48} className="text-white" strokeWidth={1.5} />
                </div>
                <div className="flex-1">
                  <h2 className="text-4xl font-serif mb-2 text-gray-900">{bookData.title}</h2>
                  <p className="text-xl text-gray-600 mb-3">by {bookData.author}</p>
                  <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 mb-4">
                    <span className="bg-rose-100 px-3 py-1 rounded-full">{bookData.genre}</span>
                    <span>{bookData.publicationYear}</span>
                  </div>
                  
                  {/* Ratings Display */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                    {/* Official Rating Card */}
                    <div className="relative overflow-hidden bg-gradient-to-br from-amber-500 to-orange-600 p-6 rounded-2xl shadow-lg transform transition-transform hover:scale-105">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                      <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
                      <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-3">
                          <Star className="text-white fill-white" size={20} />
                          <p className="text-sm font-bold text-white/90 tracking-wide uppercase">Official Rating</p>
                        </div>
                        <div className="flex items-end gap-3 mb-3">
                          <span className="text-6xl font-bold text-white leading-none">{bookData.rating}</span>
                          <span className="text-2xl text-white/80 pb-2">/5</span>
                        </div>
                        <div className="flex gap-1">
                          {renderStars(bookData.rating, true)}
                        </div>
                        <p className="text-white/70 text-sm mt-3">Professional critics consensus</p>
                      </div>
                    </div>

                    {/* Reader Rating Card */}
                    <div className="relative overflow-hidden bg-gradient-to-br from-blue-500 to-purple-600 p-6 rounded-2xl shadow-lg transform transition-transform hover:scale-105">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                      <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
                      <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-3">
                          <User className="text-white" size={20} />
                          <p className="text-sm font-bold text-white/90 tracking-wide uppercase">Reader Rating</p>
                        </div>
                        {userReviews.length > 0 ? (
                          <>
                            <div className="flex items-end gap-3 mb-3">
                              <span className="text-6xl font-bold text-white leading-none">{calculateUserRating()}</span>
                              <span className="text-2xl text-white/80 pb-2">/5</span>
                            </div>
                            <div className="flex gap-1">
                              {renderStars(parseFloat(calculateUserRating()), true)}
                            </div>
                            <p className="text-white/70 text-sm mt-3">
                              Based on {userReviews.length} reader {userReviews.length === 1 ? 'review' : 'reviews'}
                            </p>
                          </>
                        ) : (
                          <>
                            <div className="flex items-end gap-3 mb-3">
                              <span className="text-6xl font-bold text-white/50 leading-none">--</span>
                              <span className="text-2xl text-white/50 pb-2">/5</span>
                            </div>
                            <div className="flex gap-1">
                              {renderStars(0, true)}
                            </div>
                            <p className="text-white/70 text-sm mt-3">No reader reviews yet</p>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <p className="mt-6 text-gray-700 leading-relaxed text-lg">{bookData.summary}</p>
            </div>

            {/* Official Reviews Section */}
            <div className="bg-white/90 backdrop-blur rounded-3xl p-8 shadow-xl border-2 border-purple-100">
              <div className="flex items-center gap-3 mb-6">
                <Star className="text-amber-500" size={28} />
                <h3 className="text-3xl font-serif text-gray-900">Official Reviews</h3>
              </div>
              <div className="space-y-4">
                {bookData.reviews.map((review, index) => (
                  <div
                    key={index}
                    className="bg-gradient-to-r from-purple-50 to-rose-50 p-6 rounded-2xl border border-purple-100"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className="font-semibold text-gray-800">{review.reviewer}</span>
                      <div className="flex gap-1">
                        {renderStars(review.rating)}
                      </div>
                    </div>
                    <p className="text-gray-700 leading-relaxed">{review.text}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* User Reviews Section */}
            <div className="bg-white/90 backdrop-blur rounded-3xl p-8 shadow-xl border-2 border-blue-100">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <MessageSquare className="text-blue-500" size={28} />
                  <h3 className="text-3xl font-serif text-gray-900">Reader Reviews</h3>
                </div>
                <button
                  onClick={() => setShowReviewForm(!showReviewForm)}
                  className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-xl hover:shadow-lg transition-all duration-300 hover:scale-105 flex items-center gap-2"
                >
                  <User size={18} />
                  Add Your Review
                </button>
              </div>

              {/* Review Form */}
              {showReviewForm && (
                <div className="mb-6 bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-2xl border-2 border-blue-200">
                  <h4 className="font-semibold text-gray-800 mb-4">Share Your Thoughts</h4>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Your Name</label>
                      <input
                        type="text"
                        value={newReview.name}
                        onChange={(e) => setNewReview({...newReview, name: e.target.value})}
                        placeholder="Enter your name"
                        className="w-full px-4 py-2 rounded-xl border border-blue-200 focus:border-blue-400 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Your Rating</label>
                      <div className="flex gap-2">
                        {[1, 2, 3, 4, 5].map((rating) => (
                          <button
                            key={rating}
                            type="button"
                            onClick={() => setNewReview({...newReview, rating})}
                            className="focus:outline-none transition-transform hover:scale-110"
                          >
                            <Star
                              size={32}
                              className={rating <= newReview.rating ? "fill-amber-400 text-amber-400" : "text-gray-300"}
                            />
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Your Review</label>
                      <textarea
                        value={newReview.text}
                        onChange={(e) => setNewReview({...newReview, text: e.target.value})}
                        placeholder="What did you think about this book?"
                        rows="4"
                        className="w-full px-4 py-2 rounded-xl border border-blue-200 focus:border-blue-400 focus:outline-none resize-none"
                      />
                    </div>
                    <div className="flex gap-3">
                      <button
                        onClick={saveUserReview}
                        className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-xl hover:shadow-lg transition-all"
                      >
                        Submit Review
                      </button>
                      <button
                        onClick={() => {
                          setShowReviewForm(false);
                          setNewReview({ name: '', rating: 5, text: '' });
                        }}
                        className="bg-gray-200 text-gray-700 px-6 py-2 rounded-xl hover:bg-gray-300 transition-all"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* User Reviews List */}
              {loadingReviews ? (
                <div className="text-center py-8 text-gray-500">Loading reviews...</div>
              ) : userReviews.length > 0 ? (
                <div className="space-y-4">
                  {userReviews.map((review, index) => (
                    <div
                      key={index}
                      className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-2xl border border-blue-100"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <div className="bg-blue-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-semibold">
                            {review.name.charAt(0).toUpperCase()}
                          </div>
                          <span className="font-semibold text-gray-800">{review.name}</span>
                        </div>
                        <div className="flex gap-1">
                          {renderStars(review.rating)}
                        </div>
                      </div>
                      <p className="text-gray-700 leading-relaxed">{review.text}</p>
                      <p className="text-xs text-gray-500 mt-2">
                        {new Date(review.date).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <User size={48} className="text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">No reader reviews yet. Be the first to share your thoughts!</p>
                </div>
              )}
            </div>

            {/* Facts Section */}
            <div className="bg-white/90 backdrop-blur rounded-3xl p-8 shadow-xl border-2 border-orange-100">
              <div className="flex items-center gap-3 mb-6">
                <Sparkles className="text-orange-500" size={28} />
                <h3 className="text-3xl font-serif text-gray-900">Interesting Facts</h3>
              </div>
              <div className="space-y-3">
                {bookData.facts.map((fact, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-4 bg-gradient-to-r from-orange-50 to-rose-50 p-5 rounded-2xl border border-orange-100"
                  >
                    <Info className="text-orange-500 mt-1 flex-shrink-0" size={20} />
                    <p className="text-gray-700 leading-relaxed">{fact}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Initial State */}
        {!bookData && !loading && !error && (
          <div className="text-center py-16">
            <div className="inline-block p-8 bg-white/60 backdrop-blur rounded-3xl border-2 border-dashed border-rose-200">
              <Book size={64} className="text-rose-300 mx-auto mb-4" strokeWidth={1.5} />
              <p className="text-gray-500 text-lg">Enter a book title above to get started</p>
            </div>
          </div>
        )}
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Crimson+Text:ital,wght@0,400;0,600;1,400&family=Inter:wght@300;400;500;600&display=swap');
        
        body {
          font-family: 'Inter', sans-serif;
        }
        
        .font-serif {
          font-family: 'Crimson Text', serif;
        }
        
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.6s ease-out;
        }
      `}</style>
    </div>
  );
}
